# 独立验收报告（verifier 视角，非 WB 自述）

- 验收人：DSH agent（用户指定的「验证程序」一方）
- 首次验收：2026-10-22 00:49；Mathlib 补齐后复验：2026-10-22 11:15（Asia/Hong_Kong）
- 被测件：`/home/tudi/dsh-work/lean-auto/`（WorkBuddy / Hy4 preview 编写，三轮）
- 模型端：ModelScope 免费档（真实 HTTP 调用），主要用 `Qwen/Qwen3.5-397B-A17B`、`ZhipuAI/GLM-5.2`
- Lean：**真实 Lean 4.36.0-rc1**（官方 x86_64 发布包，装在 `~/lean4/`；`~/.elan` 未用）
- Mathlib：**已装**——源码与 8 个依赖由用户在 Windows 上 `git clone` 后打包传回（`mathlib-src.tgz`，SHA256 校验一致），服务器端 `lake exe cache get` 拉完 9063 个预编译文件（`.lake` 7.1GB）
- Python：3.12.3（宿主）

## 一、验收项与结果

| # | 验收项 | 结果 |
|---|---|---|
| 1 | `python3 -m compileall lean_auto` | 通过 |
| 2 | 自带单测 `python3 -m unittest discover -s tests` | **109 passed** |
| 3 | 独立对抗测试（我另写 32 个，见下） | **32 passed** |
| 4 | 真实 Lean + 真实模型，`examples/core/problem.json`（无 Mathlib） | **通过**，attempt 1，exit 0，`#print axioms` 为 `does not depend on any axioms` |
| 5 | **真实 Lean + Mathlib，PPT 的 cube 题**（`examples/cube/problem.json`） | **通过**，attempt 2：第 1 轮真实编译失败，回灌报错后第 2 轮通过；`#print axioms` = `[propext, Classical.choice, Quot.sound]` |
| 6 | JSONL / Markdown 产物 | 字段齐全，`runs/e2e-cube2/` 可复查 |
| 7 | 失败路径（模型超时） | exit 1，`llm_error` 正确落盘 |
| 8 | 配置错误路径 | `LLM_TIMEOUT=abc` / `0` → exit 2，错误信息明确 |
| 9 | API key 不泄漏 | stdout/stderr/JSONL 均无 key |
| 10 | 静态闸门不启动 Lean | 计数验证：被闸门拦下时 `runner` 调用次数为 0 |
| 11 | 超时分支 | `LEAN_TIMEOUT=1` + 假 Lean → `exit_code=124` |
| 12 | HTTP API（`serve` 模式） | 自测 11 个；宿主机 `POST /v1/check` 用真 Lean 通过；容器内 `GET /healthz` + `/v1/check` 通过（9.7s），`POST /v1/prove` 因 ModelScope 限流超时未跑通 |

## 二、独立对抗测试覆盖（`/tmp/lean-verify/adv_test.py`）

- **闸门**：注释里的 `sorry` 不误判；嵌套块注释；`sorry`/`admit`/`axiom` 真出现时必须拦；把 `ℤ` 改成 `ℕ`、把 `6` 改成 `2`、整段删掉定理 → 全部 `statement_mismatch`；多行声明仍能匹配；等价写法（`Int`/全角括号/`∀`/`→`）放行、`|` 替 `∣` 报 `symbol_drift`。
- **判定**：exit≠0、输出含 `error:`、缺 `#print axioms`、`sorryAx`、`native_decide` 产生的 `Lean.ofReduceBool`、无公理（`does not depend on any axioms`）。
- **抽取**：```lean / 无语言标注 / 无围栏带前后解释 / 没定理。
- **主循环**：先 fail 后 pass → JSONL 恰好两条且顺序正确；修复 prompt 带上一次代码与真实报错原文；耗尽次数；闸门拦下时不调用 Lean。
- **CLI**：真子进程 + 假 OpenAI HTTP 服务：通过 exit 0、缺 `LLM_MODEL` exit 2、题面路径不存在 exit 2、LLM 连不上 exit 1、key 不落盘。
- **Runner**：子进程超时 → 124 且输出含「超时」。

## 三、真实端到端（证据）

### 3.1 无 Mathlib 的 core 题

```
[lean-auto] attempt 1: pass (ok) 0.3s
[lean-auto] 结果: 通过（1 次尝试）
EXIT=0
```

`runs/e2e-final/core-add-zero-*.jsonl` 中模型真写的代码：

```lean
import Init
theorem nat_add_zero (n : Nat) : n + 0 = n :=
  rfl
#print axioms nat_add_zero
```

Lean 输出 `'nat_add_zero' does not depend on any axioms`。

### 3.2 PPT 的 cube 题（真 Mathlib，真修复闭环）

`runs/e2e-cube2/cube-*.jsonl` 两条记录：

- **attempt 1（fail, lean_exit_nonzero, 6.98s）**：模型写
  `Int.emod_nonneg n (by norm_num : (0:ℤ) < 6)`，Lean 真报错：
  `Application type mismatch: The argument has type 0 < 6 but is expected to have type 6 ≠ 0`。
  注意输出里 `#print axioms` 也打印了 `[propext, sorryAx, ...]`——但 `verify` 先看 exit code，直接判 fail，不会被这行骗过。
- **attempt 2（pass, 6.27s）**：模型把两处改成
  `apply Int.emod_nonneg; norm_num` / `apply Int.emod_lt_of_pos; norm_num`，其余 rcases/simp 不变。
  Lean 输出 `'n_cube_sub_n_dvd_six' depends on axioms: [propext, Classical.choice, Quot.sound]`——正好是 PPT 里那三条。

即：**生成 → 真编译 → 真报错回灌 → 修改 → 通过** 整条链已经在真实 Lean + Mathlib 下跑通。

### 3.3 HTTP API 与容器

- `python3 -m lean_auto serve` 起服务，`/healthz`、`/v1/prove`、`/v1/check` 三个端点；
- 宿主机实测：`/v1/check` 提交 cube 的已知通过证明 → `ok=true`、axioms 三条、5.7s；
- 容器内实测（`lean-auto:api`，`docker run -p 18081:8000`）：`/healthz` 返回 `lean_cmd=lake --dir /mathlib env lean`，`/v1/check` 同样通过（9.7s）；
- `POST /v1/prove` 在容器里跑真实模型时遇到 ModelScope 120 秒超时（`llm_error`），与容器无关；该路径由 11 个单测（含注入 Fake LLM/Runner 的修复闭环）覆盖。

## 四、说明与限制（不粉饰）

1. **Mathlib 的安装方式（2026-10-22 已解决）**：服务器 `git clone github.com` 仍不通（134 秒后 `Failed to connect to github.com port 443`），所以改由用户在 Windows 上克隆 `mathlib4` 与 8 个依赖（`plausible/LeanSearchClient/importGraph/proofwidgets/aesop/Qq/batteries/Cli`，按 `lake-manifest.json` 的 rev 钉死），打包成 95MB 的 `mathlib-src.tgz` 传回；服务器侧只跑 `lake exe cache get` 下载预编译 olean。`lean-toolchain` 与服务器 `~/lean4` 同为 `v4.36.0-rc1`。
2. **真实失败→修复闭环已补跑**：见 3.2，cube 第 1 轮真报错、第 2 轮通过。之前「只在单测层验证」的说法作废。
3. **Lean 不在 PATH**：`LEAN_CMD` 用绝对路径（无 Mathlib 时 `$HOME/lean4/bin/lean`；有 Mathlib 时 `lake env lean` + `LEAN_CWD=/home/tudi/dsh-work/mathlib`）。
4. **字体/字符**：闸门比对已升级为 `canonical()`——先按实测等价的别名归一（`ℤ/Int`、`ℕ/Nat`、`→/->`、`↔/<->`、`∀/forall`、`∃/exists`、`≤/<=`、`≥/>=`），再做 NFKC（全角括号/冒号/空格），最后压空白。只把 `∣` 打成 `|` 的代码报新错误类 `symbol_drift`（`|` 在 Lean 里不是整除），不再报 `statement_mismatch`。
5. **Mathlib 下每次验证变慢**：`import Mathlib` 首次约 19 秒、之后每次 6–7 秒（core 只要 0.3 秒）。这是 Mathlib 本身的 import 开销，不是程序问题；`LEAN_TIMEOUT` 默认 180 秒够用。
6. **模型侧不稳定**：同样的 cube 题，GLM-5.2 在 180 秒上限内没返回（记 `llm_error`），Qwen 3.5 正常。换模型时把 `LLM_TIMEOUT` 调大即可。

## 五、复现

```bash
cd /home/tudi/dsh-work/lean-auto

# 无 Mathlib（core 题）
export LLM_MODEL=Qwen/Qwen3.5-397B-A17B
export OPENAI_BASE_URL=https://api-inference.modelscope.cn/v1
export OPENAI_API_KEY=<ModelScope key>
export LLM_TIMEOUT=120
export LEAN_CMD=$HOME/lean4/bin/lean
export LEAN_CWD=$PWD
python3 -m unittest discover -s tests
python3 -m lean_auto run --problem examples/core/problem.json --max-attempts 3 --out runs/e2e-final

# 有 Mathlib（PPT 的 cube 题）
export PATH="$HOME/lean4/bin:$PATH"
export LEAN_CMD="lake env lean"
export LEAN_CWD=/home/tudi/dsh-work/mathlib
python3 -m lean_auto run --problem examples/cube/problem.json --max-attempts 3 --out runs/e2e-cube
```
