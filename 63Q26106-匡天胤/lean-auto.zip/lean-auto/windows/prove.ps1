param(
    [Parameter(Mandatory = $true)][string]$Problem,
    [string]$Model = "Qwen/Qwen3.5-27B",
    [string]$BaseUrl = "https://api-inference.modelscope.cn/v1",
    [string]$ApiKey = $env:MODELSCOPE_API_KEY,
    [int]$MaxAttempts = 3,
    [string]$Server = "http://127.0.0.1:8000"
)

# ASCII-only script on purpose: PowerShell 5.1 reads .ps1 as ANSI without a BOM,
# so non-ASCII text would be mangled. Keep this file pure ASCII.

if (-not (Test-Path $Problem)) { Write-Error "Problem file not found: $Problem"; exit 2 }
if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    Write-Error "Missing API key: pass -ApiKey, or set `$env:MODELSCOPE_API_KEY"
    exit 2
}

$prob = Get-Content $Problem -Raw -Encoding UTF8 | ConvertFrom-Json
$body = @{
    problem      = $prob
    model        = @{ base_url = $BaseUrl; api_key = $ApiKey; name = $Model; timeout = 240 }
    max_attempts = $MaxAttempts
} | ConvertTo-Json -Depth 10

try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
    $r = Invoke-RestMethod -Uri "$Server/v1/prove" -Method Post `
        -ContentType "application/json; charset=utf-8" -Body $bytes -TimeoutSec 1800
} catch {
    Write-Error "Request failed: $($_.Exception.Message)"
    exit 1
}

Write-Host ""
if ($r.ok) { Write-Host "RESULT: PASS" -ForegroundColor Green }
else { Write-Host "RESULT: FAIL ($($r.error_class))" -ForegroundColor Yellow }
Write-Host ("attempts: {0}" -f $r.attempts)
Write-Host ("axioms:   {0}" -f ($r.axioms -join ", "))

if ($r.records) {
    Write-Host ""
    Write-Host "rounds:"
    $r.records | Select-Object attempt, verdict, error_class, exit_code, duration |
        Format-Table -AutoSize | Out-String | Write-Host
}

if ($r.ok -and $r.code) {
    Write-Host "final code:"
    Write-Host $r.code
}

if ($r.jsonl) { Write-Host ("`nlog file: .\runs\{0}" -f $r.jsonl) }
