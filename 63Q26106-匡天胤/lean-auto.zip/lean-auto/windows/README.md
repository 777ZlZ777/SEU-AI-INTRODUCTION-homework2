# 在 Windows 上用 lean-auto

前提：Docker Desktop 已启动、镜像 `lean-auto:api` 已 load。整个工具就是一个容器：里面是 Ubuntu + Lean 4.36 + Mathlib + 程序，对外只开 8000 端口的 HTTP API。

## 一次性准备

```powershell
# 建个工作目录（后面所有命令都在这里跑）
mkdir D:\lean-auto
cd D:\lean-auto
mkdir runs

# 启动容器（-v 把容器里的 /work/runs 映射到本机 .\runs，日志才不会丢）
docker run -d --name lean-auto -p 8000:8000 -v "${PWD}\runs:/work/runs" lean-auto:api

# 确认活着
curl.exe http://127.0.0.1:8000/healthz
```

把 `prove.ps1` 和 `problem-template.json` 放进 `D:\lean-auto`。

## 日常使用

```powershell
cd D:\lean-auto
$env:MODELSCOPE_API_KEY = "ms-xxxx"          # 你的 key，只在当前 PowerShell 会话有效

# 复制模板改题目
copy problem-template.json problem.json
notepad problem.json

# 跑
.\prove.ps1 -Problem .\problem.json
```

指定别的模型：

```powershell
.\prove.ps1 -Problem .\problem.json -Model "Qwen/Qwen3.5-397B-A17B"
```

## 题目文件（problem.json）

```json
{
  "id": "even-sq-add",
  "import": "Mathlib",
  "natural": "对任意自然数 n，n^2 + n 是偶数",
  "statement": "theorem even_sq_add_self (n : Nat) : Even (n ^ 2 + n)",
  "allowed_axioms": ["propext", "Classical.choice", "Quot.sound"]
}
```

| 字段 | 说明 |
|---|---|
| `id` | 标识，决定日志文件名 |
| `import` | 默认 Mathlib；纯 core 题写 `Init` |
| `natural` | 自然语言题面，给模型看 |
| `statement` | **钉死**的 Lean 声明（到 `:=` 前），模型必须原样照抄，闸门会逐字比对 |
| `allowed_axioms` | 可省略，默认 `propext / Classical.choice / Quot.sound` |

`statement` 里用 `Nat` 或 `ℕ`、`Int` 或 `ℤ` 都行（闸门会归一）。

## 看结果

- 屏幕：`ok`、尝试次数、每轮 `verdict/error_class/exit_code/duration`、最终代码；
- 落盘：`D:\lean-auto\runs\<id>-<时间>.jsonl`（每轮完整代码 + Lean 输出）和 `.md`（总结）；
- 容器日志：`docker logs --tail 50 lean-auto`。

## 生命周期

```powershell
docker stop lean-auto      # 停
docker start lean-auto     # 再启动（配置不变）
docker rm -f lean-auto     # 删容器（镜像还在）
docker images | Select-String lean-auto
```

## 常见问题

| 现象 | 原因 / 处理 |
|---|---|
| 第一次请求 20–30 秒 | 正常，`import Mathlib` 首次加载慢；之后每次 5–10 秒 |
| `502 模型调用失败` | 上游 429/超时；换模型或把请求里的 `timeout` 调大 |
| `400 缺少 model.name` | 请求里没给模型名，且容器环境没有 `LLM_MODEL` |
| `503 busy` | 并发上限 2 个请求，等前一个结束 |
| 中文变乱码 | 用 `prove.ps1`（内部按 UTF-8 编码）；不要用 `curl -d` 直接拼中文 |
| 容器启动失败 | `docker logs lean-auto` 看原因；先确认 `docker version` 有 Server 段 |
