"""从 LLM 返回文本中抽取 Lean 代码。

优先 ```lean 块 → 其次任意 ``` 块 → 退化为整段（去掉前后解释文字）。
结果必须包含 theorem，否则抛 ExtractError。
"""

from __future__ import annotations

import re

_FENCE_RE = re.compile(
    r"```[ \t]*([A-Za-z0-9_+.-]*)[ \t]*\r?\n(.*?)(?:```|\Z)", re.DOTALL
)
_THEOREM_RE = re.compile(r"\btheorems?\b")
_NAME_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_'.]*)")
_NAME_LOOSE_RE = re.compile(r"\btheorem\s+([A-Za-z_][A-Za-z0-9_'.]*)")
_CODE_START_RE = re.compile(
    r"^\s*(import|theorem|lemma|example|open|namespace|section|def|structure|instance|class)\b"
)
# 用于退化路径里判断「这一行还是不是代码」
_CODE_LINE_RE = re.compile(
    r"^\s*(?:#|[-+*/^:=|()\[\]{},.≠≤≥∀∃]"
    r"|import\b|open\b|namespace\b|section\b|end\b|where\b|with\b|theorem\b|lemma\b"
    r"|example\b|def\b|axiom\b|variable\b|by\b|have\b|show\b|let\b|set\b|obtain\b"
    r"|exact\b|apply\b|rw\b|simp\b|norm_num\b|ring\b|omega\b|linarith\b|nlinarith\b"
    r"|intro\b|rcases\b|cases\b|induction\b|constructor\b|calc\b|use\b|suffices\b"
    r"|instance\b|structure\b|class\b|noncomputable\b|universe\b|attribute\b"
    r"|mutual\b|fun\b|match\b|if\b|then\b|else\b|all_goals\b|any_goals\b|try\b"
    r"|repeat\b|first\b|push_neg\b|contrapose\b|exfalso\b|absurd\b|rfl\b|trivial\b"
    r"|positivity\b|gcongr\b|field_simp\b|nth_rewrite\b)"
)


class ExtractError(Exception):
    """抽不出可用的 Lean 代码。"""


def theorem_name(statement: str) -> str:
    """从定理声明里取名字，取不到返回空串。"""
    m = _NAME_RE.search(statement or "")
    if m:
        return m.group(1)
    m = _NAME_LOOSE_RE.search(statement or "")
    return m.group(1) if m else ""


def _looks_like_code(line: str) -> bool:
    if not line.strip():
        return True
    if line[:1].isspace():
        return True
    return bool(_CODE_LINE_RE.match(line))


def _trim_prose(text: str) -> str:
    """退化路径：丢掉正文前后的解释文字。"""
    lines = text.replace("\r\n", "\n").split("\n")
    start = 0
    for i, line in enumerate(lines):
        if _CODE_START_RE.match(line):
            start = i
            break
    else:
        return text.strip()
    end = len(lines)
    while end > start and not _looks_like_code(lines[end - 1]):
        end -= 1
    while end > start and not lines[end - 1].strip():
        end -= 1
    return "\n".join(lines[start:end]).strip()


def extract_lean(text: str) -> str:
    if text is None:
        raise ExtractError("模型返回为空")
    blocks = _FENCE_RE.findall(text)
    lean_blocks = [body for lang, body in blocks if lang.strip().lower() == "lean"]
    plain_blocks = [body for lang, body in blocks if not lang.strip()]
    other_blocks = [body for _, body in blocks if body.strip()]

    if lean_blocks:
        code = lean_blocks[0]
    elif plain_blocks:
        code = plain_blocks[0]
    elif other_blocks:
        code = other_blocks[0]
    else:
        code = _trim_prose(text)
    code = code.strip()
    if not _THEOREM_RE.search(code):
        raise ExtractError("抽取结果中没有 theorem，拒绝采用")
    return code
