"""提示词：按课堂幻灯片原话写死的硬要求。"""

from __future__ import annotations

from .config import DEFAULT_IMPORT
from .extract import theorem_name

_RULE_TEMPLATE = (
    "1. 代码必须以 `import {imp}` 开头；\n"
    "2. 定理声明必须原样照抄，一个字符都不许改（包括名字、参数类型、结论）；\n"
    "3. 不得使用 sorry、admit，不得自行添加任何 axiom；\n"
    "4. 代码末尾必须加一行 `#print axioms {name}`；\n"
    "5. 只输出一个 ```lean 代码块，不要输出任何解释文字。"
)


def build_rules(name: str, imp: str = None) -> str:
    return _RULE_TEMPLATE.format(
        name=name or "<定理名字>", imp=imp or DEFAULT_IMPORT
    )


def build_problem_prompt(problem) -> str:
    name = theorem_name(problem.statement)
    imp = getattr(problem, "import_", None) or DEFAULT_IMPORT
    return (
        "你是 Lean 4 证明助手。请为下面这道数学命题写出完整、可编译通过的 Lean 4 代码。\n"
        "\n"
        "【自然语言命题】\n"
        f"{problem.natural}\n"
        "\n"
        "【必须原样使用的定理声明】\n"
        f"{problem.statement}\n"
        "\n"
        "【输出硬要求】\n"
        f"{build_rules(name, imp)}\n"
        "\n"
        "允许依赖的公理只有 propext、Classical.choice、Quot.sound。"
        "若 #print axioms 输出里出现 sorryAx 或其它公理，说明证明没做完（用了 sorry），必须重写。\n"
        "\n"
        "直接给出完整代码。"
    )


def build_repair_prompt(problem, code: str, error_text: str) -> str:
    name = theorem_name(problem.statement)
    imp = getattr(problem, "import_", None) or DEFAULT_IMPORT
    return (
        "你上一次给出的 Lean 4 代码没有通过检查。下面是【完整代码原文】和【报错原文】，"
        "请修正后重新给出完整的 Lean 4 代码。\n"
        "\n"
        "【自然语言命题】\n"
        f"{problem.natural}\n"
        "\n"
        "【必须原样使用的定理声明（不许改，命题不许换）】\n"
        f"{problem.statement}\n"
        "\n"
        "【上一次的完整代码原文】\n"
        "```lean\n"
        f"{code}\n"
        "```\n"
        "\n"
        "【Lean 报错/检查输出原文】\n"
        "```text\n"
        f"{error_text}\n"
        "```\n"
        "\n"
        "【输出硬要求】\n"
        f"{build_rules(name, imp)}\n"
        "\n"
        "保持原命题不变，不许通过改命题、加 axiom、用 sorry/admit 的方式绕过报错。\n"
        "\n"
        "直接给出修正后的完整代码。"
    )
