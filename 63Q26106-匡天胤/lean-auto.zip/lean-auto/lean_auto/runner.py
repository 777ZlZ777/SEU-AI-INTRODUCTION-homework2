"""把代码落到项目内 .work/attempt-N.lean 并调用 Lean。"""

from __future__ import annotations

import shlex
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from .config import Config

TIMEOUT_EXIT_CODE = 124
WORK_DIRNAME = ".work"


class RunnerError(Exception):
    """无法启动 Lean。"""


@dataclass
class RunResult:
    code: str
    exit_code: int
    output: str
    duration: float
    path: str = ""


def write_attempt(code: str, attempt: int, cwd: str) -> Path:
    work = Path(cwd) / WORK_DIRNAME
    work.mkdir(parents=True, exist_ok=True)
    path = work / ("attempt-%d.lean" % attempt)
    path.write_text(code, encoding="utf-8")
    return path


def run_lean(code: str, cfg: Config = None, attempt: int = 1, cwd: str = None) -> RunResult:
    if cfg is None:
        cfg = Config.from_env()
    cwd = cwd if cwd is not None else cfg.lean_cwd
    path = write_attempt(code, attempt, cwd)
    cmd = shlex.split(cfg.lean_cmd) + [str(path)]
    started = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=cfg.lean_timeout,
        )
        duration = time.monotonic() - started
        return RunResult(
            code=code,
            exit_code=proc.returncode,
            output=proc.stdout or "",
            duration=duration,
            path=str(path),
        )
    except subprocess.TimeoutExpired as exc:
        duration = time.monotonic() - started
        partial = exc.output or ""
        if isinstance(partial, bytes):
            partial = partial.decode("utf-8", "replace")
        return RunResult(
            code=code,
            exit_code=TIMEOUT_EXIT_CODE,
            output="%s\n[lean-auto] 超时（%s 秒）" % (partial, cfg.lean_timeout),
            duration=duration,
            path=str(path),
        )
    except (OSError, ValueError) as exc:
        raise RunnerError("启动 Lean 失败（%s）：%s" % (" ".join(cmd), exc))
