"""主循环：生成 → 静态闸门 → Lean 验证 → 失败就把「完整代码+报错」回灌重试。"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import gate, prompts, verify
from .config import Config
from .extract import ExtractError, extract_lean
from .llm import LlmError, complete
from .runner import RunResult, run_lean

OUTPUT_LIMIT = 4000
STATIC_SKIP_EXIT_CODE = -1


@dataclass
class PipelineResult:
    ok: bool
    attempts: list = field(default_factory=list)
    jsonl_path: Path = None
    md_path: Path = None
    code: str = ""
    error_class: str = ""

    @property
    def used_attempts(self) -> int:
        return len(self.attempts)


def _trunc(s: str, limit: int = OUTPUT_LIMIT) -> str:
    s = s or ""
    return s if len(s) <= limit else s[:limit] + "...[truncated]"


def _record(attempt, code, exit_code, output, ok, error_class, duration):
    return {
        "attempt": attempt,
        "code": code,
        "exit_code": exit_code,
        "output": _trunc(output),
        "verdict": "pass" if ok else "fail",
        "error_class": error_class,
        "duration": round(float(duration), 3),
    }


def _write_md(problem, result: "PipelineResult", path: Path) -> None:
    lines = []
    lines.append("# lean-auto 运行总结：%s" % problem.id)
    lines.append("")
    lines.append("- 题面（自然语言）：%s" % problem.natural)
    lines.append("- 定理声明：`%s`" % problem.statement)
    lines.append("- 允许公理：%s" % ", ".join(problem.allowed_axioms))
    lines.append("- 结果：**%s**" % ("通过" if result.ok else "未通过"))
    lines.append("- 尝试次数：%d" % result.used_attempts)
    lines.append("- 最后一次错误类别：%s" % (result.error_class or "-"))
    lines.append("- 明细：%s" % (result.jsonl_path.name if result.jsonl_path else "-"))
    lines.append("")
    lines.append("| # | verdict | error_class | exit_code | 耗时(s) |")
    lines.append("|---|---|---|---|---|")
    for rec in result.attempts:
        lines.append(
            "| %d | %s | %s | %s | %s |"
            % (
                rec["attempt"],
                rec["verdict"],
                rec["error_class"] or "-",
                rec["exit_code"],
                rec["duration"],
            )
        )
    lines.append("")
    if result.ok and result.code:
        lines.append("## 最终通过的代码")
        lines.append("")
        lines.append("```lean")
        lines.append(result.code)
        lines.append("```")
        lines.append("")
    else:
        last = result.attempts[-1] if result.attempts else None
        if last:
            lines.append("## 最后一次报错（截取 %d 字）" % OUTPUT_LIMIT)
            lines.append("")
            lines.append("```text")
            lines.append(last["output"])
            lines.append("```")
            lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def run_problem(
    problem,
    cfg: Config = None,
    llm=None,
    runner=None,
    out_dir=None,
    ts: str = None,
    verbose: bool = True,
) -> PipelineResult:
    if cfg is None:
        cfg = Config.from_env()
    llm_fn = llm if llm is not None else complete
    runner_fn = runner if runner is not None else run_lean
    ts = ts or datetime.now().strftime("%Y%m%d-%H%M%S")

    out = Path(out_dir) if out_dir is not None else Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    jsonl_path = out / ("%s-%s.jsonl" % (problem.id, ts))
    md_path = out / ("%s-%s.md" % (problem.id, ts))

    result = PipelineResult(ok=False, jsonl_path=jsonl_path, md_path=md_path)
    prompt = prompts.build_problem_prompt(problem)

    with jsonl_path.open("w", encoding="utf-8") as fh:
        for attempt in range(1, cfg.max_attempts + 1):
            try:
                text = llm_fn(prompt)
            except LlmError as exc:
                rec = _record(attempt, "", STATIC_SKIP_EXIT_CODE, str(exc), False, "llm_error", 0.0)
                result.error_class = "llm_error"
                result.attempts.append(rec)
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                if verbose:
                    print("[lean-auto] attempt %d: LLM 调用失败 %s" % (attempt, exc))
                break

            try:
                code = extract_lean(text)
            except ExtractError as exc:
                rec = _record(attempt, _trunc(text), STATIC_SKIP_EXIT_CODE, "", False, "extract_error", 0.0)
                result.attempts.append(rec)
                result.error_class = "extract_error"
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                if verbose:
                    print("[lean-auto] attempt %d: 抽取失败 %s" % (attempt, exc))
                prompt = prompts.build_repair_prompt(problem, "", str(exc))
                continue

            issues = gate.check_static(code, problem)
            if issues:
                detail = "静态闸门拦下: %s" % ", ".join(issues)
                rec = _record(attempt, code, STATIC_SKIP_EXIT_CODE, detail, False, issues[0], 0.0)
                result.attempts.append(rec)
                result.error_class = issues[0]
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                if verbose:
                    print("[lean-auto] attempt %d: %s" % (attempt, detail))
                prompt = prompts.build_repair_prompt(problem, code, detail)
                continue

            run_result = runner_fn(code, cfg=cfg, attempt=attempt)
            if not isinstance(run_result, RunResult):
                raise TypeError("runner 必须返回 RunResult，收到 %r" % type(run_result))
            verdict = verify.judge(run_result, problem)
            rec = _record(
                attempt,
                code,
                run_result.exit_code,
                run_result.output,
                verdict.ok,
                verdict.error_class,
                run_result.duration,
            )
            result.attempts.append(rec)
            result.error_class = verdict.error_class
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if verbose:
                print(
                    "[lean-auto] attempt %d: %s (%s) %.1fs"
                    % (
                        attempt,
                        rec["verdict"],
                        verdict.error_class or "ok",
                        run_result.duration,
                    )
                )
            if verdict.ok:
                result.ok = True
                result.code = code
                break
            prompt = prompts.build_repair_prompt(
                problem,
                code,
                (run_result.output or "") + ("\n" + verdict.detail if verdict.detail else ""),
            )

    if not result.ok and not result.error_class:
        result.error_class = "max_attempts_exhausted"
    _write_md(problem, result, md_path)
    if verbose:
        print("[lean-auto] 结果: %s（%d 次尝试）" % ("通过" if result.ok else "未通过", result.used_attempts))
        print("[lean-auto] 明细: %s" % jsonl_path)
        print("[lean-auto] 总结: %s" % md_path)
    return result
