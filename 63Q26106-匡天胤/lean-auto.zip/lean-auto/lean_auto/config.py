"""配置读取与共享数据结构。

只用标准库。环境变量：
  OPENAI_BASE_URL   默认 http://127.0.0.1:8080/v1
  OPENAI_API_KEY    默认空串（本地 llama.cpp 之类的服务端通常不需要）
  LLM_MODEL         必填
  LEAN_CMD          默认 "lake env lean"
  LEAN_CWD          默认当前目录
  LEAN_TIMEOUT      默认 180 秒
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_BASE_URL = "http://127.0.0.1:8080/v1"
DEFAULT_LEAN_CMD = "lake env lean"
DEFAULT_LEAN_TIMEOUT = 180
LLM_TIMEOUT = 600
DEFAULT_MAX_ATTEMPTS = 5
DEFAULT_ALLOWED_AXIOMS = ("propext", "Classical.choice", "Quot.sound")
DEFAULT_IMPORT = "Mathlib"


class ConfigError(Exception):
    """配置错误：CLI 退出码 2。"""


def _read_positive_int(env, key: str, default: int) -> int:
    """读一个必须 >=1 的整数环境变量。"""
    raw = env.get(key)
    if raw is None or not str(raw).strip():
        return default
    raw = str(raw).strip()
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError("%s 必须是整数，收到: %r" % (key, raw))
    if value < 1:
        raise ConfigError("%s 必须 >= 1，收到: %d" % (key, value))
    return value


@dataclass
class Problem:
    id: str
    natural: str
    statement: str
    allowed_axioms: tuple = field(default_factory=lambda: DEFAULT_ALLOWED_AXIOMS)
    # `import` 是 Python 关键字，字段名用 import_；
    # __post_init__ 里再挂一个 getattr(p, "import") 能取到的同名属性。
    import_: str = DEFAULT_IMPORT

    def __post_init__(self):
        object.__setattr__(self, "import", self.import_)

    @classmethod
    def from_dict(cls, data: dict) -> "Problem":
        missing = [k for k in ("id", "natural", "statement") if not data.get(k)]
        if missing:
            raise ConfigError("problem.json 缺少字段: %s" % ", ".join(missing))
        axioms = data.get("allowed_axioms")
        if axioms is None:
            axioms = list(DEFAULT_ALLOWED_AXIOMS)
        imp = data.get("import")
        if imp is None or not str(imp).strip():
            imp = DEFAULT_IMPORT
        return cls(
            id=str(data["id"]),
            natural=str(data["natural"]),
            statement=str(data["statement"]),
            allowed_axioms=tuple(str(a) for a in axioms),
            import_=str(imp).strip(),
        )

    @classmethod
    def from_json(cls, path) -> "Problem":
        p = Path(path)
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raise ConfigError("找不到题面文件: %s" % p)
        except json.JSONDecodeError as exc:
            raise ConfigError("题面文件不是合法 JSON: %s (%s)" % (p, exc))
        if not isinstance(data, dict):
            raise ConfigError("题面文件顶层必须是对象: %s" % p)
        return cls.from_dict(data)


@dataclass
class Config:
    base_url: str
    api_key: str
    model: str
    lean_cmd: str
    lean_cwd: str
    lean_timeout: int
    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    out_dir: Path = field(default_factory=lambda: Path("runs"))
    llm_timeout: int = LLM_TIMEOUT

    @classmethod
    def from_env(
        cls,
        env=None,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        out_dir=None,
    ) -> "Config":
        e = os.environ if env is None else env
        model = (e.get("LLM_MODEL") or "").strip()
        if not model:
            raise ConfigError("环境变量 LLM_MODEL 必填（例如 LLM_MODEL=local）")
        base_url = (e.get("OPENAI_BASE_URL") or DEFAULT_BASE_URL).strip()
        lean_cmd = (e.get("LEAN_CMD") or DEFAULT_LEAN_CMD).strip()
        lean_cwd = (e.get("LEAN_CWD") or os.getcwd()).strip()
        raw_timeout = (e.get("LEAN_TIMEOUT") or str(DEFAULT_LEAN_TIMEOUT)).strip()
        try:
            lean_timeout = int(raw_timeout)
        except ValueError:
            raise ConfigError("LEAN_TIMEOUT 必须是整数，收到: %r" % raw_timeout)
        llm_timeout = _read_positive_int(e, "LLM_TIMEOUT", LLM_TIMEOUT)
        if max_attempts < 1:
            raise ConfigError("--max-attempts 必须 >= 1，收到: %d" % max_attempts)
        return cls(
            base_url=base_url.rstrip("/"),
            api_key=e.get("OPENAI_API_KEY") or "",
            model=model,
            lean_cmd=lean_cmd,
            lean_cwd=lean_cwd,
            lean_timeout=lean_timeout,
            max_attempts=max_attempts,
            out_dir=Path(out_dir) if out_dir else Path("runs"),
            llm_timeout=llm_timeout,
        )
