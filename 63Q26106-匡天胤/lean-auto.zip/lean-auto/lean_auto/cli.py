"""命令行入口：
  python3 -m lean_auto run   --problem ... [--max-attempts 5] [--out runs/]
  python3 -m lean_auto serve [--host 0.0.0.0] [--port 8000] [--concurrency 2]

退出码：0 = 通过，1 = 未通过，2 = 配置错误。
"""

from __future__ import annotations

import argparse
import sys

from .config import Config, ConfigError, Problem
from .llm import LlmError
from .pipeline import run_problem
from .runner import RunnerError

EXIT_OK = 0
EXIT_FAIL = 1
EXIT_CONFIG = 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python3 -m lean_auto",
        description="AI 生成 Lean 证明 → Lean 验证 → 报错回灌修复",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="跑一道题")
    run.add_argument("--problem", required=True, help="problem.json 路径")
    run.add_argument("--max-attempts", type=int, default=5, help="最多尝试次数，默认 5")
    run.add_argument("--out", default="runs", help="运行产物目录，默认 runs/")
    srv = sub.add_parser("serve", help="起 HTTP API（POST /v1/prove、POST /v1/check）")
    srv.add_argument("--host", default="0.0.0.0", help="监听地址，默认 0.0.0.0")
    srv.add_argument("--port", type=int, default=8000, help="监听端口，默认 8000")
    srv.add_argument("--concurrency", type=int, default=None, help="并发上限，默认取 LEAN_AUTO_CONCURRENCY 或 2")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "serve":
        from .server import serve

        serve(host=args.host, port=args.port, concurrency=args.concurrency)
        return EXIT_OK
    try:
        problem = Problem.from_json(args.problem)
        cfg = Config.from_env(max_attempts=args.max_attempts, out_dir=args.out)
    except ConfigError as exc:
        print("[lean-auto] 配置错误: %s" % exc, file=sys.stderr)
        return EXIT_CONFIG
    try:
        result = run_problem(problem, cfg=cfg)
    except LlmError as exc:
        print("[lean-auto] 调用大模型失败: %s" % exc, file=sys.stderr)
        return EXIT_FAIL
    except RunnerError as exc:
        print("[lean-auto] %s" % exc, file=sys.stderr)
        return EXIT_FAIL
    return EXIT_OK if result.ok else EXIT_FAIL
