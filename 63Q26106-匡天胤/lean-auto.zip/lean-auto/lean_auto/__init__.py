"""lean-auto：AI 生成 Lean 证明 + Lean 验证 + 报错回灌修复。"""

from .config import Config, ConfigError, Problem
from .extract import ExtractError, extract_lean
from .llm import LlmError, complete
from .pipeline import PipelineResult, run_problem
from .runner import RunResult, run_lean
from .verify import Verdict, judge

__all__ = [
    "Config",
    "ConfigError",
    "Problem",
    "ExtractError",
    "extract_lean",
    "LlmError",
    "complete",
    "PipelineResult",
    "run_problem",
    "RunResult",
    "run_lean",
    "Verdict",
    "judge",
]

__version__ = "0.1.0"
