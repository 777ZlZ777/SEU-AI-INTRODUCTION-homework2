"""判定一次 Lean 运行是否真的通过。

三道关：exit_code、输出里有没有 error:、#print axioms 的方括号列表。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_AXIOMS_RE = re.compile(r"depends on axioms\s*:\s*\[([^\]]*)\]", re.DOTALL)
_NO_AXIOM_RE = re.compile(r"does not depend on any axioms")
_ERROR_RE = re.compile(r"\berror\s*:")


@dataclass
class Verdict:
    ok: bool
    error_class: str = ""
    detail: str = ""
    axioms: list = field(default_factory=list)


def parse_axioms(output: str) -> list:
    """解析输出里所有 `#print axioms` 的方括号列表（去重、保序）。"""
    found = []
    for m in _AXIOMS_RE.finditer(output or ""):
        for raw in m.group(1).split(","):
            name = raw.strip().strip("`").strip("'").strip()
            if name and name not in found:
                found.append(name)
    return found


def axioms_printed(output: str) -> bool:
    return bool(_AXIOMS_RE.search(output or "") or _NO_AXIOM_RE.search(output or ""))


def judge(result, problem) -> Verdict:
    output = result.output or ""
    if result.exit_code != 0:
        return Verdict(False, "lean_exit_nonzero", "lean 退出码 %d" % result.exit_code)
    if _ERROR_RE.search(output):
        line = ""
        for ln in output.splitlines():
            if _ERROR_RE.search(ln):
                line = ln.strip()
                break
        return Verdict(False, "lean_error", "输出含 error: %s" % line)
    if not axioms_printed(output):
        return Verdict(False, "axioms_not_printed", "输出里没有 #print axioms 结果")
    axioms = parse_axioms(output)
    bad = [a for a in axioms if a == "sorryAx"]
    if bad:
        return Verdict(False, "sorry_axiom", "公理列表含 sorryAx，说明证明没做完", axioms)
    allowed = set(problem.allowed_axioms or ())
    bad = [a for a in axioms if a not in allowed]
    if bad:
        return Verdict(
            False,
            "axiom_not_allowed",
            "出现未授权的公理: %s" % ", ".join(bad),
            axioms,
        )
    return Verdict(True, "", "#print axioms: [%s]" % ", ".join(axioms), axioms)
