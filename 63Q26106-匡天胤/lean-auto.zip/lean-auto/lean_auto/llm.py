"""OpenAI 兼容 /v1/chat/completions 调用，只用 urllib。"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

from .config import Config, ConfigError, LLM_TIMEOUT


class LlmError(Exception):
    """调用大模型失败（含状态码与响应片段）。"""


def _snippet(body: str, limit: int = 400) -> str:
    body = (body or "").strip()
    return body if len(body) <= limit else body[:limit] + "..."


def complete(prompt: str, cfg: Config = None, timeout: int = None) -> str:
    """单次调用大模型。超时默认用 cfg.llm_timeout（环境变量 LLM_TIMEOUT），可显式覆盖。"""
    if cfg is None:
        try:
            cfg = Config.from_env()
        except ConfigError as exc:
            raise LlmError(str(exc))
    if timeout is None:
        timeout = cfg.llm_timeout or LLM_TIMEOUT
    try:
        timeout = int(timeout)
    except (TypeError, ValueError):
        raise LlmError("超时时间必须是整数，收到: %r" % (timeout,))
    if timeout < 1:
        raise LlmError("超时时间必须 >= 1 秒，收到: %d" % timeout)
    url = cfg.base_url.rstrip("/") + "/chat/completions"
    payload = json.dumps(
        {
            "model": cfg.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
        }
    ).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if cfg.api_key:
        headers["Authorization"] = "Bearer " + cfg.api_key
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    status = None
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            body = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        status = exc.code
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")
        except Exception:
            body = ""
        raise LlmError(
            "LLM 返回状态码 %s：%s" % (status, _snippet(body))
        )
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, TimeoutError):
            raise LlmError("调用 LLM 超时（%s 秒）：%s" % (timeout, url))
        raise LlmError("无法连接 LLM 服务 %s：%s" % (url, exc.reason))
    except TimeoutError:
        raise LlmError("调用 LLM 超时（%s 秒）：%s" % (timeout, url))

    if status != 200:
        raise LlmError("LLM 返回状态码 %s：%s" % (status, _snippet(body)))
    try:
        data = json.loads(body)
        return data["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise LlmError("LLM 响应解析失败（%s）：%s" % (exc, _snippet(body)))
