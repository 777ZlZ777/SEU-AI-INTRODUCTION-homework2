"""静态闸门：不启动 Lean 就能拦下的硬错误。

返回「问题列表」，每项是一个短字符串 code：
  sorry / admit / axiom / statement_mismatch / symbol_drift
注释（-- 与 /- -/，含嵌套）里的不算。

声明比对分两层：
  1. canonical()：把「Lean 解析结果相同」的写法归一（ℤ/Int、ℕ/Nat、→/->、↔/<->、
     ∀/forall、∃/exists、≤/<=、≥/>=，再加 NFKC 处理全角符号与全角空格）；
  2. symbol_drift：只差 ∣ 与 |（Lean 不把 | 当整除，必须单独报，不能当等价放行）。
"""

from __future__ import annotations

import re
import unicodedata

_SORRY_RE = re.compile(r"\bsorry\b")
_ADMIT_RE = re.compile(r"\badmit\b")
_AXIOM_RE = re.compile(r"\baxiom\b")
_THEOREM_RE = re.compile(r"\btheorem\b")
_CUT_RE = re.compile(r":=|\bby\b")


def strip_comments(code: str) -> str:
    """删掉 Lean 的行注释与（可嵌套的）块注释。"""
    out = []
    i = 0
    n = len(code)
    depth = 0
    while i < n:
        if depth == 0 and code.startswith("--", i):
            j = code.find("\n", i)
            i = n if j < 0 else j
            continue
        if code.startswith("/-", i):
            depth += 1
            i += 2
            continue
        if depth > 0:
            if code.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
            continue
        out.append(code[i])
        i += 1
    return "".join(out)


def compress(s: str) -> str:
    """压缩空白，用于比对定理声明。"""
    return " ".join((s or "").split())


# 经 Lean 4.36 实测「两种写法解析结果相同」的别名；统一成 ASCII 规范形。
# 先做别名替换，再做 NFKC（否则 NFKC 会把 ℤ→Z、ℕ→N，别名就匹配不上了）。
_ALIASES = (
    ("ℤ", "Int"),
    ("ℕ", "Nat"),
    ("ℝ", "Real"),
    ("ℂ", "Complex"),
    ("ℚ", "Rat"),
    ("→", "->"),
    ("↔", "<->"),
    ("∀", "forall"),
    ("∃", "exists"),
    ("≤", "<="),
    ("≥", ">="),
)

# Lean 里 ∣（U+2223）是整除，|（U+007C）不是；后者写进声明会解析失败。
_DIVIDES = "∣"
_PIPE = "|"


def canonical(s: str) -> str:
    """把等价的写法归一，再压缩空白。只做「Lean 语义不变」的替换。"""
    out = s or ""
    for raw, normalized in _ALIASES:
        out = out.replace(raw, normalized)
    out = unicodedata.normalize("NFKC", out)
    return compress(out)


def _as_divides(s: str) -> str:
    """把 | 也当成 ∣，仅用于识别「符号写错」而不是「命题被改」。"""
    return canonical(s).replace(_PIPE, _DIVIDES)


def _candidate_declarations(code: str):
    """从代码里截出所有 theorem 声明（到 := 前、或 by 前，都没有则到行尾）。"""
    decls = []
    for m in _THEOREM_RE.finditer(code):
        rest = code[m.start():]
        km = _CUT_RE.search(rest)
        if km:
            cut = km.start()
        else:
            nl = rest.find("\n")
            cut = len(rest) if nl < 0 else nl
        decls.append(rest[:cut])
    return decls


def check_statement(code: str, statement: str) -> bool:
    """代码里是否有与题面等价（canonical 之后相同）的定理声明。"""
    want = canonical(statement)
    decls = _candidate_declarations(strip_comments(code or ""))
    if not decls:
        return False
    return any(canonical(d) == want for d in decls)


def statement_drift(code: str, statement: str) -> bool:
    """声明只在 ∣ / | 上有差别：命题没被改，是符号打错了。"""
    want = _as_divides(statement)
    decls = _candidate_declarations(strip_comments(code or ""))
    return any(_as_divides(d) == want for d in decls)


def check_static(code: str, problem) -> list:
    issues = []
    body = strip_comments(code or "")
    if _SORRY_RE.search(body):
        issues.append("sorry")
    if _ADMIT_RE.search(body):
        issues.append("admit")
    if _AXIOM_RE.search(body):
        issues.append("axiom")
    if not check_statement(code, problem.statement):
        issues.append("symbol_drift" if statement_drift(code, problem.statement) else "statement_mismatch")
    return issues
