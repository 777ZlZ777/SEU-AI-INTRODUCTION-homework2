"""HTTP API（只用标准库），供容器外部调用。

端点：
  GET  /healthz     存活检查
  POST /v1/prove    给一道题：生成 → 验证 → 报错回灌，返回结果
  POST /v1/check    直接校验一段 Lean 代码（不调模型）

模型不放在镜像里：每个请求自带 model 配置（base_url / api_key / name / timeout），
也可以用环境变量兜底。API key 只在该请求内使用，不落盘、不写日志。
"""

from __future__ import annotations

import inspect
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import verify
from .config import Config, ConfigError, Problem
from .llm import LlmError, complete as llm_complete
from .pipeline import run_problem
from .runner import RunnerError, run_lean

API_VERSION = "1.0"
MAX_BODY = 1 << 20  # 1 MiB
DEFAULT_PORT = 8000
DEFAULT_CONCURRENCY = 2


class _Handler(BaseHTTPRequestHandler):
    server_version = "lean-auto/" + API_VERSION
    protocol_version = "HTTP/1.1"

    # 不把请求行/请求体打进日志（里面可能有 api_key）
    def log_message(self, fmt, *args):  # noqa: A003
        pass

    # ---------- 基础 ----------

    def _send(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        raw_len = self.headers.get("Content-Length")
        if raw_len is None:
            raise ValueError("缺少 Content-Length")
        try:
            length = int(raw_len)
        except ValueError:
            raise ValueError("Content-Length 不是整数")
        if length < 0 or length > MAX_BODY:
            raise ValueError("请求体超过 %d 字节上限" % MAX_BODY)
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("请求体不是合法 JSON: %s" % exc)
        if not isinstance(data, dict):
            raise ValueError("请求体顶层必须是对象")
        return data

    def _route(self) -> str:
        return self.path.split("?", 1)[0].rstrip("/") or "/"

    # ---------- 路由 ----------

    def do_GET(self):  # noqa: N802
        route = self._route()
        if route == "/healthz":
            cfg = getattr(self.server, "lean_settings", {})
            self._send(200, {
                "ok": True,
                "service": "lean-auto",
                "version": API_VERSION,
                "lean_cmd": cfg.get("lean_cmd", ""),
                "lean_cwd": cfg.get("lean_cwd", ""),
            })
        elif route == "/v1":
            self._send(200, {
                "endpoints": ["GET /healthz", "POST /v1/prove", "POST /v1/check"],
                "prove_body": {
                    "problem": {"id": "cube", "natural": "…", "statement": "theorem …",
                                 "import": "Mathlib", "allowed_axioms": ["propext"]},
                    "model": {"base_url": "https://…/v1", "api_key": "…",
                               "name": "Qwen/Qwen3.5-397B-A17B", "timeout": 120},
                    "max_attempts": 3,
                    "out_dir": "runs",
                },
            })
        else:
            self._send(404, {"error": "not found", "path": route})

    def do_POST(self):  # noqa: N802
        route = self._route()
        if route not in ("/v1/prove", "/v1/check"):
            self._send(404, {"error": "not found", "path": route})
            return
        try:
            payload = self._read_json()
        except ValueError as exc:
            self._send(400, {"error": str(exc)})
            return

        sem = self.server.sem
        # 排队上限之外直接 503，避免 Lean 进程堆爆
        if not sem.acquire(blocking=False):
            self._send(503, {"error": "busy: 并发已达上限，请稍后重试"})
            return
        try:
            if route == "/v1/prove":
                status, body = self._prove(payload)
            else:
                status, body = self._check(payload)
        except ConfigError as exc:
            status, body = 400, {"error": str(exc)}
        except LlmError as exc:
            status, body = 502, {"error": "模型调用失败: %s" % exc}
        except RunnerError as exc:
            status, body = 500, {"error": "Lean 启动失败: %s" % exc}
        except Exception as exc:  # pragma: no cover - 兜底，避免连接被掐
            status, body = 500, {"error": "内部错误: %r" % exc}
        finally:
            sem.release()
        self._send(status, body)

    # ---------- 业务 ----------

    @staticmethod
    def _problem(payload: dict) -> Problem:
        raw = payload.get("problem")
        if not isinstance(raw, dict):
            raise ConfigError("缺少 problem 对象")
        return Problem.from_dict(raw)

    @staticmethod
    def _cfg(payload: dict, attempts: int, require_model: bool = True) -> Config:
        model = payload.get("model") or {}
        if not isinstance(model, dict):
            raise ConfigError("model 必须是对象")
        env = dict(os.environ)
        mapping = (
            ("base_url", "OPENAI_BASE_URL"),
            ("api_key", "OPENAI_API_KEY"),
            ("name", "LLM_MODEL"),
            ("timeout", "LLM_TIMEOUT"),
        )
        for src, dst in mapping:
            value = model.get(src)
            if value not in (None, ""):
                env[dst] = str(value)
        if not str(env.get("LLM_MODEL") or "").strip():
            if require_model:
                raise ConfigError("缺少 model.name（或环境变量 LLM_MODEL）")
            env["LLM_MODEL"] = "unused"  # /v1/check 不调模型，但仍需要一个 Config
        out_dir = payload.get("out_dir") or env.get("LEAN_AUTO_OUT_DIR") or "runs"
        return Config.from_env(env=env, max_attempts=attempts, out_dir=out_dir)

    def _prove(self, payload: dict):
        problem = self._problem(payload)
        attempts = payload.get("max_attempts", 3)
        if not isinstance(attempts, int) or attempts < 1:
            raise ConfigError("max_attempts 必须是 >=1 的整数")
        cfg = self._cfg(payload, attempts)
        result = run_problem(
            problem,
            cfg=cfg,
            llm=_bind_cfg(getattr(self.server, "llm_fn", llm_complete), cfg),
            runner=getattr(self.server, "runner_fn", run_lean),
            verbose=False,
        )
        last = result.attempts[-1] if result.attempts else {}
        axioms = verify.parse_axioms(last.get("output", ""))
        return 200, {
            "ok": result.ok,
            "attempts": result.used_attempts,
            "error_class": result.error_class,
            "code": result.code,
            "axioms": axioms,
            "records": result.attempts,
            "jsonl": result.jsonl_path.name if result.jsonl_path else "",
            "md": result.md_path.name if result.md_path else "",
        }

    def _check(self, payload: dict):
        problem = self._problem(payload)
        code = payload.get("code")
        if not isinstance(code, str) or not code.strip():
            raise ConfigError("缺少 code 字符串")
        cfg = self._cfg(payload, 1, require_model=False)
        from . import gate

        issues = gate.check_static(code, problem)
        if issues:
            return 200, {
                "ok": False,
                "error_class": issues[0],
                "issues": issues,
                "axioms": [],
                "output": "",
            }
        run = getattr(self.server, "runner_fn", run_lean)(code, cfg=cfg, attempt=1)
        verdict = verify.judge(run, problem)
        return 200, {
            "ok": verdict.ok,
            "error_class": verdict.error_class,
            "issues": [],
            "axioms": verdict.axioms,
            "exit_code": run.exit_code,
            "output": run.output,
            "duration": round(run.duration, 3),
        }


def _bind_cfg(fn, cfg):
    """把请求里的 model 配置绑定到 llm 调用上（Fake 只接受 prompt 时退回单参调用）。"""
    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        params = {}
    if "cfg" in params:
        def call(prompt):
            return fn(prompt, cfg=cfg)
        return call
    return fn


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def make_server(host: str = "0.0.0.0", port: int = DEFAULT_PORT,
                llm=None, runner=None, concurrency: int = None) -> _Server:
    """创建（但不启动）HTTP 服务器；llm/runner 可注入，方便测试。"""
    srv = _Server((host, port), _Handler)
    srv.llm_fn = llm or llm_complete
    srv.runner_fn = runner or run_lean
    srv.sem = threading.BoundedSemaphore(concurrency or int(
        os.environ.get("LEAN_AUTO_CONCURRENCY", DEFAULT_CONCURRENCY)))
    srv.lean_settings = {
        "lean_cmd": os.environ.get("LEAN_CMD", ""),
        "lean_cwd": os.environ.get("LEAN_CWD", ""),
    }
    return srv


def serve(host: str = "0.0.0.0", port: int = DEFAULT_PORT, concurrency: int = None) -> None:
    srv = make_server(host, port, concurrency=concurrency)
    print("[lean-auto] HTTP API on http://%s:%d  (health: /healthz, prove: POST /v1/prove)"
          % (host, port), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
