# Docker 镜像说明

| 镜像 | 大小 | 内容 | 用途 |
|---|---|---|---|
| `lean-auto:api` | 14.5GB | Ubuntu 24.04 + Python 3.12 + git + Lean 4.36.0-rc1 + **Mathlib** + 程序 | **推荐**：自带 HTTP API 服务，`docker run -p 8000:8000` 即用 |
| `lean-auto:full` | 14.5GB | 同上，但入口仍是 CLI | 命令行批跑 |
| `lean-auto:lean` | 4.5GB | 无 Mathlib，运行时挂 volume | 镜像小、Mathlib 放外部 |

三个镜像里都**没有任何 API key**：key 由调用方在 `POST /v1/prove` 的 `model` 字段里带（或运行时 `-e` 传入），已用真实 key 全文扫描镜像，0 命中。

## 起服务（推荐）

```bash
docker run -d --name lean-auto -p 8000:8000 lean-auto:api
curl -s http://127.0.0.1:8000/healthz
```

或者用 compose：

```bash
cd docker && docker compose up -d
```

然后调接口，**模型配置每次请求自带**：

```bash
curl -s -X POST http://127.0.0.1:8000/v1/prove \
  -H 'Content-Type: application/json' -d '{
    "problem": {"id":"core-add-zero","import":"Init","natural":"对任意自然数 n，n + 0 = n",
                 "statement":"theorem nat_add_zero (n : Nat) : n + 0 = n",
                 "allowed_axioms":["propext"]},
    "model": {"base_url":"https://api-inference.modelscope.cn/v1",
               "api_key":"<调用方自己的 key>",
               "name":"Qwen/Qwen3.5-397B-A17B","timeout":120},
    "max_attempts": 3
  }'
```

只校验代码（不调模型）：

```bash
curl -s -X POST http://127.0.0.1:8000/v1/check \
  -H 'Content-Type: application/json' \
  -d '{"problem":{"id":"t","natural":"…","statement":"theorem t : (1:Nat)+1=2"},
       "code":"import Mathlib\ntheorem t : (1 : Nat) + 1 = 2 := rfl\n#print axioms t\n"}'
```

## 镜像里的环境

| 路径 / 变量 | 内容 |
|---|---|
| `/opt/lean4` | Lean 4.36.0-rc1（含 lake、leantar） |
| `/mathlib` | Mathlib 源码 + 7.1GB 预编译 olean（`lean-toolchain` = v4.36.0-rc1） |
| `/app` | lean-auto 源码、tests、examples |
| `/work` | 可写临时目录（`.work/attempt-N.lean`、`/work/runs` 产物） |
| `LEAN_CMD` | `lake --dir /mathlib env lean` |
| `LEAN_CWD` | `/work` |
| `LEAN_AUTO_CONCURRENCY` | `2`（并发上限，超了返回 503） |
| `LEAN_AUTO_OUT_DIR` | `/work/runs` |

`lake --dir /mathlib` 是为了把「包目录」和「执行目录」分开：`/mathlib` 属主是 root、非 root 用户写不了 `.work/`，所以临时文件落在可写的 `/work`。

## 跑 CLI（不进服务）

```bash
docker run --rm --user 1000:1000 -e HOME=/tmp -v "$PWD/runs":/out \
  -e LLM_MODEL -e OPENAI_BASE_URL -e OPENAI_API_KEY \
  lean-auto:api run --problem examples/cube/problem.json --max-attempts 3 --out /out
```

## 构建过程（复现）

构建上下文要装 3GB Lean + 7GB Mathlib，用 `docker cp` 比 `docker build` 省事：

```bash
# 1) 基础镜像
docker run -d --name la-build ubuntu:24.04 sleep infinity
docker exec la-build apt-get update -qq
docker exec la-build apt-get install -y -qq --no-install-recommends python3 ca-certificates git
docker cp ~/lean4 la-build:/opt/lean4
docker exec la-build mkdir -p /app
for x in lean_auto tests examples README.md VERIFICATION.md; do
  docker cp ~/dsh-work/lean-auto/$x la-build:/app/
done
docker commit --change 'WORKDIR /app' \
  --change 'ENTRYPOINT ["python3","-m","lean_auto"]' \
  --change 'ENV PATH=/opt/lean4/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' \
  la-build lean-auto:lean

# 2) full：把 Mathlib 复制进去
docker run -d --name la-full --entrypoint sleep lean-auto:lean infinity
docker exec la-full mkdir -p /mathlib
docker cp /home/tudi/dsh-work/mathlib/. la-full:/mathlib/
docker exec la-full sh -c 'git config --system --add safe.directory "*"; mkdir -p /work; chmod 777 /work'
docker commit --change 'WORKDIR /app' \
  --change 'ENTRYPOINT ["python3","-m","lean_auto"]' \
  --change 'ENV PATH=/opt/lean4/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' \
  --change 'ENV LEAN_CMD="lake --dir /mathlib env lean"' \
  --change 'ENV LEAN_CWD=/work' \
  la-full lean-auto:full

# 3) api：默认入口改成 serve
docker run -d --name la-api --entrypoint sleep lean-auto:full infinity
docker cp ~/dsh-work/lean-auto/lean_auto/. la-api:/app/lean_auto/
docker commit --change 'ENTRYPOINT ["python3","-m","lean_auto"]' \
  --change 'CMD ["serve","--host","0.0.0.0","--port","8000"]' \
  --change 'EXPOSE 8000' \
  --change 'WORKDIR /app' \
  --change 'ENV PATH=/opt/lean4/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' \
  --change 'ENV LEAN_CMD="lake --dir /mathlib env lean"' \
  --change 'ENV LEAN_CWD=/work' \
  --change 'ENV LEAN_AUTO_OUT_DIR=/work/runs' \
  --change 'ENV LEAN_AUTO_CONCURRENCY=2' \
  la-api lean-auto:api
docker rm -f la-build la-full la-api
```

## 搬到别的机器

```bash
docker save lean-auto:api | gzip -1 > lean-auto-api.tar.gz   # 预计 4–5GB
# 目标机
gunzip -c lean-auto-api.tar.gz | docker load
docker run -d -p 8000:8000 lean-auto:api
```

目标机要求 Linux x86_64 + Docker（Docker Desktop 亦可），内存 10GB 以上，CPU 越强 Lean 越快。

## 已知边界

- 首次 `import Mathlib` 约 10–30 秒，之后每次 6–7 秒；`LEAN_TIMEOUT` 默认 180 秒。
- `lake --dir /mathlib env lean` 会打印 `repository has local changes` 告警（`docker cp` 改了 mtime），不影响判定（只看 exit code、`error:`、`#print axioms`）。
- 镜像无 pip、无 curl/wget；HTTP 服务是标准库 `http.server`，不要直接暴露公网（没有鉴权）。
- `docker system prune -a` 会删掉这些大镜像；清理时用 `docker image rm` 精确删。
