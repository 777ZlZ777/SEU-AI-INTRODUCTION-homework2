# lean-auto

把课堂那套流程（S1–S5）做成一条命令：
**固定提示词让 AI 输出完整 Lean 代码 → 静态闸门 → `lake env lean` 验收 → 报错就把「完整代码 + 报错原文」回灌给 AI 修正，原命题不变。**

只用 Python 3 标准库（urllib / json / subprocess / re / argparse / dataclasses / unittest），不 pip install。

## 用法

```bash
cd /home/tudi/dsh-work/lean-auto

export OPENAI_BASE_URL=http://127.0.0.1:8080/v1   # 默认
export OPENAI_API_KEY=sk-xxx                     # 本地服务端一般留空即可
export LLM_MODEL=qwen                            # 必填
export LEAN_CMD="lake env lean"                   # 默认
export LEAN_CWD=/path/to/lean/project            # 默认当前目录
export LEAN_TIMEOUT=180                          # 默认 180 秒
export LLM_TIMEOUT=600                          # 默认 600 秒，单次大模型调用上限

python3 -m lean_auto run --problem examples/cube/problem.json --max-attempts 5 --out runs/
```

### 环境变量

| 变量 | 默认值 | 含义 |
|---|---|---|
| `OPENAI_BASE_URL` | `http://127.0.0.1:8080/v1` | OpenAI 兼容接口地址 |
| `OPENAI_API_KEY` | 空 | 本地服务端一般留空；不写就不发 Authorization 头 |
| `LLM_MODEL` | **必填** | 模型名 |
| `LLM_TIMEOUT` | `600` | 单次大模型调用上限（秒），必须 >=1，非整数报错 |
| `LEAN_CMD` | `lake env lean` | 跑 Lean 的命令 |
| `LEAN_CWD` | 当前目录 | Lean 工程目录，`.work/attempt-N.lean` 写在这里 |
| `LEAN_TIMEOUT` | `180` | 单次 Lean 编译上限（秒），超时记 `exit_code=124` |

`LLM_TIMEOUT` 是遇到「模型对着假命题长时间思考」这类情况的收紧手段：把它调到比外层超时更小的值，超时会以 `llm_error` 记进 JSONL（不是无限等下去）。

退出码：`0` = 通过；`1` = 未通过；`2` = 配置错误（题面文件不存在、缺 `LLM_MODEL`、`LLM_TIMEOUT` 非法等）。


## HTTP API（serve 模式）

把同一套流程当服务跑，模型不写死在服务里——每个请求自带 `model` 配置：

```bash
export LEAN_CMD="lake env lean"
export LEAN_CWD=/path/to/mathlib
python3 -m lean_auto serve --host 0.0.0.0 --port 8000
```

| 端点 | 说明 |
|---|---|
| `GET /healthz` | 存活检查，返回 `lean_cmd` / `lean_cwd` |
| `POST /v1/prove` | 给题目，跑「生成 → 验证 → 回灌修复」，返回结果与每轮记录 |
| `POST /v1/check` | 只校验一段 Lean 代码（不调模型） |

```bash
curl -s http://127.0.0.1:8000/healthz

curl -s -X POST http://127.0.0.1:8000/v1/prove \
  -H 'Content-Type: application/json' -d '{
    "problem": {"id":"core-add-zero","import":"Init","natural":"对任意自然数 n，n + 0 = n",
                 "statement":"theorem nat_add_zero (n : Nat) : n + 0 = n"},
    "model": {"base_url":"https://api-inference.modelscope.cn/v1",
               "api_key":"...","name":"Qwen/Qwen3.5-397B-A17B","timeout":120},
    "max_attempts": 3, "out_dir": "runs"
  }'
```

响应字段：`ok`、`attempts`、`error_class`、`code`、`axioms`、`records[]`（每轮 `verdict/error_class/exit_code/duration/output`）、`jsonl`、`md`。

约束与行为：

- 并发上限 `LEAN_AUTO_CONCURRENCY`（默认 2），超了直接 `503`，不排队堆 Lean 进程；
- 请求体上限 1 MiB；`model.name` 缺省时可回退到环境变量 `LLM_MODEL`，都没有则 `400`；
- `api_key` 只在本次请求内使用，不落盘、不写访问日志；
- `POST /v1/check` 不调模型，可以只带 `problem` + `code`。

## problem.json

```json
{"id":"cube",
 "import":"Mathlib",
 "natural":"对任意整数 n，6 整除 n^3-n",
 "statement":"theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n",
 "allowed_axioms":["propext","Classical.choice","Quot.sound"]}
```

- `import`：代码开头的 import 模块名，**不写默认 `Mathlib`；本机没装 Mathlib 时用 `Init`**（见 `examples/core/problem.json`，用 `Init` 只依赖核心库）。
- `allowed_axioms`：省略时默认就是 `propext / Classical.choice / Quot.sound`。

示例：`examples/cube/problem.json`（Mathlib）、`examples/core/problem.json`（Init）。

## 流程细节

1. **提示词**（`prompts.py`）：写死五条硬要求——以 `import {problem.import}` 开头（默认 `Mathlib`，题面里写 `Init` 就要求 `import Init`）；定理声明原样照抄；不得用 sorry / admit / 自行加 axiom；末尾加 `#print axioms <定理名字>`；只输出一个 ```lean 块。修复轮额外附上「上一次的完整代码原文 + Lean 报错原文」。
2. **抽取**（`extract.py`）：优先 ```lean 块 → 其次无语言标注的 ``` 块 → 再退化为整段（去掉前后解释文字）；结果里没有 `theorem` 直接抛 `ExtractError`。
3. **静态闸门**（`gate.py`，不启动 Lean）：检测 `sorry` / `admit` / `axiom`（注释里的不算，块注释支持嵌套）；把代码里的定理声明截到 `:=` 或 `by` 之前，做两层比对——先 `canonical()` 归一（`ℤ/Int`、`ℕ/Nat`、`→/->`、`↔/<->`、`∀/forall`、`∃/exists`、`≤/<=`、`≥/>=`，以及 NFKC 处理全角括号/spaces），再压空白与 `problem.statement` 比；语义变了记 `statement_mismatch`，只把 `∣` 打成 `|` 记 `symbol_drift`（`|` 在 Lean 里不是整除，不能放行）。
4. **跑 Lean**（`runner.py`）：代码写到 `LEAN_CWD/.work/attempt-N.lean`，执行 `LEAN_CMD <file>`，stdout/stderr 合并；超时（默认 180s）记为 `exit_code=124`。
5. **判定**（`verify.py`）：`exit_code≠0` → fail；输出含 `error:` → fail；解析 `#print axioms` 的方括号列表，出现 `sorryAx` 或不在 `allowed_axioms` 里的名字 → fail；输出里根本没有 `#print axioms` 结果 → fail。
6. **主循环**（`pipeline.py`）：attempt 1..N，每轮往 `runs/<id>-<ts>.jsonl` 追加一条记录，通过即停，失败就拼修复 prompt 重试；最后写 `runs/<id>-<ts>.md` 总结。

JSONL 每条记录的字段：

| 字段 | 说明 |
|---|---|
| `attempt` | 第几次 |
| `code` | 这一轮交给 Lean 的完整代码 |
| `exit_code` | Lean 退出码；`-1` 表示这一轮没跑到 Lean（静态闸门 / 抽取失败 / LLM 失败） |
| `output` | Lean 输出，截断到 4000 字 |
| `verdict` | `pass` / `fail` |
| `error_class` | 见下表 |
| `duration` | 秒，3 位小数 |

`error_class` 取值：`sorry` `admit` `axiom` `statement_mismatch` `symbol_drift` `extract_error` `llm_error`
`lean_exit_nonzero` `lean_error` `sorry_axiom` `axiom_not_allowed` `axioms_not_printed`。

## 目录

```
lean_auto/   __init__.py __main__.py config.py llm.py prompts.py
             extract.py gate.py runner.py verify.py pipeline.py
             server.py cli.py
tests/       unittest，假 LLM + 假 runner，不联网、不需要 Lean
examples/cube/problem.json    import: Mathlib
examples/core/problem.json    import: Init（没装 Mathlib 时用这个）
runs/        运行产物（自动创建）
.work/       Lean 临时文件（自动创建，在 LEAN_CWD 下）
```

## 状态（真实执行结果）

执行环境：Linux，Python 3.13.12 与 Python 3.12.3 均通过。WorkBuddy 编写期间本机没有 Lean，下面标「验收方实测」的条目是 DSH 验收方在装好 Lean 4.36.0-rc1 + Mathlib 后补跑的。

编译：

```
$ python3 -m compileall lean_auto
Listing 'lean_auto'...
Compiling 'lean_auto/__init__.py'...
Compiling 'lean_auto/__main__.py'...
Compiling 'lean_auto/cli.py'...
Compiling 'lean_auto/config.py'...
Compiling 'lean_auto/extract.py'...
Compiling 'lean_auto/gate.py'...
Compiling 'lean_auto/llm.py'...
Compiling 'lean_auto/pipeline.py'...
Compiling 'lean_auto/prompts.py'...
Compiling 'lean_auto/runner.py'...
Compiling 'lean_auto/verify.py'...
```

单测（`python3 -m unittest discover -s tests -v`，109 个用例，真实输出）：

```
test_args_parsed (test_cli.TestCli.test_args_parsed) ... ok
test_exit_code_matches_result (test_cli.TestCli.test_exit_code_matches_result) ... ok
test_llm_error_is_exit_fail (test_cli.TestCli.test_llm_error_is_exit_fail) ... ok
test_missing_model_is_config_error (test_cli.TestCli.test_missing_model_is_config_error) ... ok
test_missing_problem_is_config_error (test_cli.TestCli.test_missing_problem_is_config_error) ... ok
test_bad_max_attempts (test_config.TestConfig.test_bad_max_attempts) ... ok
test_bad_timeout (test_config.TestConfig.test_bad_timeout) ... ok
test_defaults (test_config.TestConfig.test_defaults) ... ok
test_env_overrides (test_config.TestConfig.test_env_overrides) ... ok
test_llm_timeout_default_600 (test_config.TestConfig.test_llm_timeout_default_600) ... ok
test_llm_timeout_empty_falls_back (test_config.TestConfig.test_llm_timeout_empty_falls_back) ... ok
test_llm_timeout_from_env (test_config.TestConfig.test_llm_timeout_from_env) ... ok
test_llm_timeout_negative (test_config.TestConfig.test_llm_timeout_negative) ... ok
test_llm_timeout_not_an_int (test_config.TestConfig.test_llm_timeout_not_an_int) ... ok
test_llm_timeout_zero (test_config.TestConfig.test_llm_timeout_zero) ... ok
test_model_required (test_config.TestConfig.test_model_required) ... ok
test_default_axioms (test_config.TestProblem.test_default_axioms) ... ok
test_from_json_bad_json (test_config.TestProblem.test_from_json_bad_json) ... ok
test_from_json_missing_file (test_config.TestProblem.test_from_json_missing_file) ... ok
test_import_alias_attribute (test_config.TestProblem.test_import_alias_attribute) ... ok
test_import_defaults_to_mathlib (test_config.TestProblem.test_import_defaults_to_mathlib) ... ok
test_import_does_not_disturb_other_fields (test_config.TestProblem.test_import_does_not_disturb_other_fields) ... ok
test_import_empty_falls_back (test_config.TestProblem.test_import_empty_falls_back) ... ok
test_import_explicit_init (test_config.TestProblem.test_import_explicit_init) ... ok
test_missing_field (test_config.TestProblem.test_missing_field) ... ok
test_candidate_shape_passes_gate (test_examples.TestCoreExample.test_candidate_shape_passes_gate) ... ok
test_example_loads (test_examples.TestCoreExample.test_example_loads) ... ok
test_candidate_shape_passes_gate (test_examples.TestCubeExample.test_candidate_shape_passes_gate) ... ok
test_cube_import_is_mathlib (test_examples.TestCubeExample.test_cube_import_is_mathlib) ... ok
test_example_loads (test_examples.TestCubeExample.test_example_loads) ... ok
test_fallback_all_prose_raises (test_extract.TestExtract.test_fallback_all_prose_raises) ... ok
test_fallback_trims_prose (test_extract.TestExtract.test_fallback_trims_prose) ... ok
test_falls_back_to_plain_fence (test_extract.TestExtract.test_falls_back_to_plain_fence) ... ok
test_ignores_other_language_fence_only_when_no_lean (test_extract.TestExtract.test_ignores_other_language_fence_only_when_no_lean) ... ok
test_no_theorem_in_block_raises (test_extract.TestExtract.test_no_theorem_in_block_raises) ... ok
test_none_raises (test_extract.TestExtract.test_none_raises) ... ok
test_prefers_lean_fence (test_extract.TestExtract.test_prefers_lean_fence) ... ok
test_theorem_name (test_extract.TestExtract.test_theorem_name) ... ok
test_unterminated_lean_fence (test_extract.TestExtract.test_unterminated_lean_fence) ... ok
test_admit_detected (test_gate.TestCheckStatic.test_admit_detected) ... ok
test_axiom_detected (test_gate.TestCheckStatic.test_axiom_detected) ... ok
test_axioms_word_is_not_axiom_declaration (test_gate.TestCheckStatic.test_axioms_word_is_not_axiom_declaration) ... ok
test_check_statement_and_compress (test_gate.TestCheckStatic.test_check_statement_and_compress) ... ok
test_clean_code_has_no_issues (test_gate.TestCheckStatic.test_clean_code_has_no_issues) ... ok
test_multiline_declaration_ok (test_gate.TestCheckStatic.test_multiline_declaration_ok) ... ok
test_no_theorem_is_mismatch (test_gate.TestCheckStatic.test_no_theorem_is_mismatch) ... ok
test_sorry_detected (test_gate.TestCheckStatic.test_sorry_detected) ... ok
test_sorry_in_comment_ignored (test_gate.TestCheckStatic.test_sorry_in_comment_ignored) ... ok
test_statement_in_comment_does_not_count (test_gate.TestCheckStatic.test_statement_in_comment_does_not_count) ... ok
test_statement_mismatch (test_gate.TestCheckStatic.test_statement_mismatch) ... ok
test_theorem_renamed_is_mismatch (test_gate.TestCheckStatic.test_theorem_renamed_is_mismatch) ... ok
test_block_comment (test_gate.TestStripComments.test_block_comment) ... ok
test_line_comment (test_gate.TestStripComments.test_line_comment) ... ok
test_nested_block_comment (test_gate.TestStripComments.test_nested_block_comment) ... ok
test_bad_json_raises (test_llm.TestComplete.test_bad_json_raises) ... ok
test_bad_timeout_value (test_llm.TestComplete.test_bad_timeout_value) ... ok
test_connection_error_raises (test_llm.TestComplete.test_connection_error_raises) ... ok
test_explicit_timeout_overrides (test_llm.TestComplete.test_explicit_timeout_overrides) ... ok
test_no_api_key_sends_no_auth_header (test_llm.TestComplete.test_no_api_key_sends_no_auth_header) ... ok
test_non_200_raises_with_status (test_llm.TestComplete.test_non_200_raises_with_status) ... ok
test_returns_content (test_llm.TestComplete.test_returns_content) ... ok
test_timeout_raises_llm_error (test_llm.TestComplete.test_timeout_raises_llm_error) ... ok
test_timeout_wrapped_in_urlerror_raises_llm_error (test_llm.TestComplete.test_timeout_wrapped_in_urlerror_raises_llm_error) ... ok
test_uses_cfg_llm_timeout_by_default (test_llm.TestComplete.test_uses_cfg_llm_timeout_by_default) ... ok
test_bad_runner_return_type (test_pipeline.TestPipeline.test_bad_runner_return_type) ... ok
test_custom_import_flows_into_first_prompt (test_pipeline.TestPipeline.test_custom_import_flows_into_first_prompt) ... ok
test_extract_error_recorded (test_pipeline.TestPipeline.test_extract_error_recorded) ... ok
test_fail_then_pass_writes_two_records (test_pipeline.TestPipeline.test_fail_then_pass_writes_two_records) ... ok
test_llm_error_stops_loop (test_pipeline.TestPipeline.test_llm_error_stops_loop) ... ok
test_max_attempts_exhausted (test_pipeline.TestPipeline.test_max_attempts_exhausted) ... ok
test_md_summary_written (test_pipeline.TestPipeline.test_md_summary_written) ... ok
test_output_truncated_to_limit (test_pipeline.TestPipeline.test_output_truncated_to_limit) ... ok
test_pass_on_first_attempt_stops (test_pipeline.TestPipeline.test_pass_on_first_attempt_stops) ... ok
test_repair_prompt_contains_code_and_error (test_pipeline.TestPipeline.test_repair_prompt_contains_code_and_error) ... ok
test_statement_mismatch_recorded (test_pipeline.TestPipeline.test_statement_mismatch_recorded) ... ok
test_static_gate_blocks_without_running_lean (test_pipeline.TestPipeline.test_static_gate_blocks_without_running_lean) ... ok
test_problem_prompt_hard_rules (test_prompts.TestPrompts.test_problem_prompt_hard_rules) ... ok
test_repair_prompt_keeps_statement (test_prompts.TestPrompts.test_repair_prompt_keeps_statement) ... ok
test_default_prompt_uses_mathlib (test_prompts.TestPromptsImport.test_default_prompt_uses_mathlib) ... ok
test_init_prompt_uses_init_and_no_mathlib (test_prompts.TestPromptsImport.test_init_prompt_uses_init_and_no_mathlib) ... ok
test_init_repair_prompt_uses_init_and_no_mathlib (test_prompts.TestPromptsImport.test_init_repair_prompt_uses_init_and_no_mathlib) ... ok
test_error_in_output_fails (test_verify.TestJudge.test_error_in_output_fails) ... ok
test_no_axiom_output_fails (test_verify.TestJudge.test_no_axiom_output_fails) ... ok
test_no_dependency_axioms_passes (test_verify.TestJudge.test_no_dependency_axioms_passes) ... ok
test_nonzero_exit_fails (test_verify.TestJudge.test_nonzero_exit_fails) ... ok
test_pass (test_verify.TestJudge.test_pass) ... ok
test_sorry_axiom_fails (test_verify.TestJudge.test_sorry_axiom_fails) ... ok
test_unexpected_axiom_fails (test_verify.TestJudge.test_unexpected_axiom_fails) ... ok
test_verdict_dataclass_defaults (test_verify.TestJudge.test_verdict_dataclass_defaults) ... ok
test_axioms_printed (test_verify.TestParseAxioms.test_axioms_printed) ... ok
test_parse_empty (test_verify.TestParseAxioms.test_parse_empty) ... ok
test_parse_list (test_verify.TestParseAxioms.test_parse_list) ... ok
test_parse_multiple_prints (test_verify.TestParseAxioms.test_parse_multiple_prints) ... ok

----------------------------------------------------------------------
Ran 109 tests in 0.029s

OK
```

验收项对照：

| 验收项 | 结果 |
|---|---|
| `python3 -m compileall lean_auto` | 通过（见上） |
| `python3 -m unittest discover -s tests -v` 全绿 | 通过，109 passed / OK（第一轮 70 + 第二轮 12 + 第三轮 11 + 闸门归一化 5 + HTTP API 11，旧的仍全绿） |
| 假 runner 第一次报错第二次通过 → JSONL 恰好两条、verdict 正确 | 通过（`test_fail_then_pass_writes_two_records`：2 条，verdict `['fail','pass']`，`error_class` 分别为 `lean_exit_nonzero` 和 `""`） |
| 真实 `lake env lean` 跑通 cube，`#print axioms` 为三条 | **通过（验收方实测 2026-10-22）**：2 次尝试——第 1 轮真实 Lean 报 `Int.emod_nonneg` 参数类型不符，回灌后第 2 轮通过；`#print axioms` = `[propext, Classical.choice, Quot.sound]`。产物 `runs/e2e-cube2/` |

额外做过的端到端冒烟（不是真实 Lean）：本机起了个假的 OpenAI 兼容 HTTP 服务 + 用 `echo` 冒充 Lean，走完整 CLI——第 1 轮 `verdict=pass`、退出码 0、`runs/` 下产出 jsonl 与 md；另外用 `sh -c 'sleep 30'` + `LEAN_TIMEOUT=2` 验证超时分支返回 `exit_code=124`。这两项都不代表 Lean 真的编译通过。

## 第二轮改动（problem.json 支持 import 字段）

- `Problem` 增加可选字段，默认 `"Mathlib"`；`from_dict` 读 `import` 键，空值回落到 `Mathlib`。
  字段名在 Python 里是 `import_`（`import` 是关键字），同时挂了 `getattr(p, "import")` 可取的别名。
- `prompts.py` 第 1 条硬要求改成 `` 代码必须以 `import {problem.import}` 开头 ``，生成 prompt 与修复 prompt 都跟着变。
- 新增 `examples/core/problem.json`（`import: "Init"`，`theorem nat_add_zero`）。
- 新增 12 个测试：默认 Mathlib、显式 Init 生效、prompt 出现 `import Init` 且不再出现 `import Mathlib`、`examples/core` 能加载且 `check_static` 返回空列表、pipeline 首轮 prompt 带自定义 import。

## 第三轮改动（LLM 超时可配）

- `Config` 增加 `llm_timeout`（默认 600），从环境变量 `LLM_TIMEOUT` 读取；非整数或 <1 抛 `ConfigError`（CLI 退出码 2）。
- `llm.complete` 的默认超时改用 `cfg.llm_timeout`，仍保留 `timeout=` 显式覆盖；超时抛 `LlmError`（连接超时 / 读超时都算），pipeline 会把它记成 `error_class=llm_error` 并停止重试。
- 新增 11 个测试：默认 600、`LLM_TIMEOUT=5` 生效、`abc` → ConfigError、`0` / `-3` → ConfigError、空值回落 600、complete 用 `cfg.llm_timeout`、`timeout=` 覆盖生效、超时 → LlmError、`LLM_TIMEOUT` 与其它字段互不干扰。

## 还没做的

- 真实 Lean 结果由验收方补跑（`~/lean4` + `~/dsh-work/mathlib`），产物在 `runs/e2e-final/`、`runs/e2e-check2/`、`runs/e2e-cube2/`。
- **使用者实测（非本机自动跑）**：真实 Lean 4.36 + ModelScope 免费模型跑 `examples/core/problem.json` 一次通过
  （exit 0，`#print axioms` 输出 `does not depend on any axioms`）；这是使用者反馈，本仓库未伪造该结果。
- 想自己复现：`python3 -m lean_auto run --problem examples/core/problem.json`；
  装了 Mathlib 再跑 `examples/cube/problem.json`。
- `examples/cube`、`examples/core` 里的证明本身没有经过编译，只是单测里的样例形态。
