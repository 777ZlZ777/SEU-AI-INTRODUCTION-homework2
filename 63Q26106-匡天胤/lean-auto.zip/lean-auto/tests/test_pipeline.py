import json
import tempfile
import unittest
from pathlib import Path

from lean_auto.config import Config
from lean_auto.pipeline import OUTPUT_LIMIT, run_problem
from lean_auto.runner import RunResult

STATEMENT = "theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n"

GOOD_CODE = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""

BAD_CODE = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  norm_num

#print axioms n_cube_sub_n_dvd_six
"""

SORRY_CODE = GOOD_CODE.replace("  omega", "  sorry")
FAIL_OUTPUT = "cube.lean:3:36: error: tactic 'norm_num' failed\n"
OK_OUTPUT = "'n_cube_sub_n_dvd_six' depends on axioms: [propext, Classical.choice, Quot.sound]\n"


def make_problem(**kw):
    from lean_auto.config import Problem

    data = {
        "id": "cube",
        "natural": "对任意整数 n，6 整除 n^3-n",
        "statement": STATEMENT,
        "allowed_axioms": ["propext", "Classical.choice", "Quot.sound"],
    }
    data.update(kw)
    return Problem.from_dict(data)


def make_cfg(out_dir, max_attempts=5):
    return Config.from_env(
        env={"LLM_MODEL": "fake", "LEAN_CMD": "lean", "LEAN_CWD": str(out_dir)},
        max_attempts=max_attempts,
        out_dir=out_dir,
    )


class FakeLlm:
    """按脚本依次返回文本，并记录收到的 prompt。"""

    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []

    def __call__(self, prompt):
        self.prompts.append(prompt)
        return self.replies.pop(0) if self.replies else ""


class FakeRunner:
    """按脚本依次返回 RunResult，记录被调用时的代码。"""

    def __init__(self, results):
        self.results = list(results)
        self.calls = []

    def __call__(self, code, cfg=None, attempt=1, cwd=None):
        self.calls.append((attempt, code))
        item = self.results.pop(0) if self.results else RunResult(code, 0, OK_OUTPUT, 0.0)
        return RunResult(code=code, exit_code=item[0], output=item[1], duration=item[2])


class PipelineTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.out = Path(self.tmp.name) / "runs"
        self.addCleanup(self.tmp.cleanup)

    def records(self, path):
        with open(path, encoding="utf-8") as fh:
            return [json.loads(line) for line in fh if line.strip()]


class TestPipeline(PipelineTestCase):
    def test_fail_then_pass_writes_two_records(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        llm = FakeLlm([GOOD_CODE, GOOD_CODE])
        runner = FakeRunner([(1, FAIL_OUTPUT, 0.5), (0, OK_OUTPUT, 0.4)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertTrue(result.ok)
        recs = self.records(result.jsonl_path)
        self.assertEqual(len(recs), 2)
        self.assertEqual([r["verdict"] for r in recs], ["fail", "pass"])
        self.assertEqual(recs[0]["error_class"], "lean_exit_nonzero")
        self.assertEqual(recs[1]["error_class"], "")
        self.assertEqual(recs[0]["attempt"], 1)
        self.assertEqual(recs[1]["attempt"], 2)
        self.assertEqual(runner.calls[0][1], GOOD_CODE.strip())
        self.assertEqual(runner.calls[1][1], GOOD_CODE.strip())

    def test_repair_prompt_contains_code_and_error(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        llm = FakeLlm([BAD_CODE, GOOD_CODE])
        runner = FakeRunner([(1, FAIL_OUTPUT, 0.1), (0, OK_OUTPUT, 0.1)])
        run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertEqual(len(llm.prompts), 2)
        first, second = llm.prompts
        self.assertIn("import Mathlib", first)
        self.assertIn(STATEMENT, first)
        self.assertIn("#print axioms n_cube_sub_n_dvd_six", first)
        self.assertIn(BAD_CODE.strip(), second)
        self.assertIn(FAIL_OUTPUT.strip(), second)
        self.assertIn(STATEMENT, second)

    def test_pass_on_first_attempt_stops(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        llm = FakeLlm([GOOD_CODE, GOOD_CODE])
        runner = FakeRunner([(0, OK_OUTPUT, 0.1)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertTrue(result.ok)
        self.assertEqual(len(self.records(result.jsonl_path)), 1)
        self.assertEqual(len(runner.calls), 1)
        self.assertEqual(result.code, GOOD_CODE.strip())

    def test_static_gate_blocks_without_running_lean(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        llm = FakeLlm([SORRY_CODE, GOOD_CODE])
        runner = FakeRunner([(0, OK_OUTPUT, 0.1)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        recs = self.records(result.jsonl_path)
        self.assertEqual(len(recs), 2)
        self.assertEqual(recs[0]["error_class"], "sorry")
        self.assertEqual(recs[0]["verdict"], "fail")
        self.assertTrue(result.ok)
        self.assertEqual(len(runner.calls), 1)
        self.assertIn("sorry", recs[0]["output"])

    def test_statement_mismatch_recorded(self):
        problem = make_problem()
        cfg = make_cfg(self.out, max_attempts=2)
        wrong = GOOD_CODE.replace("n ^ 3 - n", "n ^ 3 + n")
        llm = FakeLlm([wrong, wrong])
        runner = FakeRunner([])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertFalse(result.ok)
        recs = self.records(result.jsonl_path)
        self.assertEqual(len(recs), 2)
        self.assertEqual(recs[0]["error_class"], "statement_mismatch")
        self.assertEqual(len(runner.calls), 0)

    def test_max_attempts_exhausted(self):
        problem = make_problem()
        cfg = make_cfg(self.out, max_attempts=3)
        llm = FakeLlm([BAD_CODE] * 3)
        runner = FakeRunner([(1, FAIL_OUTPUT, 0.1)] * 3)
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertFalse(result.ok)
        self.assertEqual(len(self.records(result.jsonl_path)), 3)
        self.assertEqual(result.error_class, "lean_exit_nonzero")

    def test_extract_error_recorded(self):
        problem = make_problem()
        cfg = make_cfg(self.out, max_attempts=2)
        llm = FakeLlm(["我不会做这道题。", GOOD_CODE])
        runner = FakeRunner([(0, OK_OUTPUT, 0.1)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        recs = self.records(result.jsonl_path)
        self.assertEqual(recs[0]["error_class"], "extract_error")
        self.assertTrue(result.ok)
        self.assertEqual(len(recs), 2)

    def test_llm_error_stops_loop(self):
        from lean_auto.llm import LlmError

        def broken(prompt):
            raise LlmError("LLM 返回状态码 500：boom")

        problem = make_problem()
        cfg = make_cfg(self.out, max_attempts=3)
        runner = FakeRunner([])
        result = run_problem(problem, cfg=cfg, llm=broken, runner=runner, verbose=False)

        self.assertFalse(result.ok)
        recs = self.records(result.jsonl_path)
        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0]["error_class"], "llm_error")
        self.assertEqual(result.error_class, "llm_error")

    def test_output_truncated_to_limit(self):
        problem = make_problem()
        cfg = make_cfg(self.out, max_attempts=1)
        llm = FakeLlm([BAD_CODE])
        runner = FakeRunner([(1, "x" * 10000, 0.1)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        recs = self.records(result.jsonl_path)
        self.assertLessEqual(len(recs[0]["output"]), OUTPUT_LIMIT + 50)

    def test_custom_import_flows_into_first_prompt(self):
        problem = make_problem(**{"import": "Init"})
        cfg = make_cfg(self.out)
        llm = FakeLlm([GOOD_CODE])
        runner = FakeRunner([(0, OK_OUTPUT, 0.1)])
        run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertEqual(problem.import_, "Init")
        self.assertIn("import Init", llm.prompts[0])
        self.assertNotIn("import Mathlib", llm.prompts[0])

    def test_md_summary_written(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        llm = FakeLlm([GOOD_CODE])
        runner = FakeRunner([(0, OK_OUTPUT, 0.1)])
        result = run_problem(problem, cfg=cfg, llm=llm, runner=runner, verbose=False)

        self.assertTrue(result.md_path.exists())
        body = result.md_path.read_text(encoding="utf-8")
        self.assertIn("通过", body)
        self.assertIn(GOOD_CODE.strip(), body)
        self.assertIn(STATEMENT, body)

    def test_bad_runner_return_type(self):
        problem = make_problem()
        cfg = make_cfg(self.out)
        with self.assertRaises(TypeError):
            run_problem(
                problem,
                cfg=cfg,
                llm=FakeLlm([GOOD_CODE]),
                runner=lambda code, **kw: "not a RunResult",
                verbose=False,
            )


if __name__ == "__main__":
    unittest.main()
