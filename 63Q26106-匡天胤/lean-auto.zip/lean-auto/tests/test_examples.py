import unittest
from pathlib import Path

from lean_auto.config import Problem
from lean_auto.gate import check_static

ROOT = Path(__file__).resolve().parent.parent
EXAMPLE = ROOT / "examples" / "cube" / "problem.json"
CORE_EXAMPLE = ROOT / "examples" / "core" / "problem.json"

CANDIDATE = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""


class TestCubeExample(unittest.TestCase):
    def test_example_loads(self):
        p = Problem.from_json(EXAMPLE)
        self.assertEqual(p.id, "cube")
        self.assertEqual(p.natural, "对任意整数 n，6 整除 n^3-n")
        self.assertEqual(
            p.statement,
            "theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n",
        )
        self.assertEqual(
            list(p.allowed_axioms), ["propext", "Classical.choice", "Quot.sound"]
        )

    def test_candidate_shape_passes_gate(self):
        p = Problem.from_json(EXAMPLE)
        self.assertEqual(check_static(CANDIDATE, p), [])

    def test_cube_import_is_mathlib(self):
        self.assertEqual(Problem.from_json(EXAMPLE).import_, "Mathlib")


CORE_CANDIDATE = """import Init

theorem nat_add_zero (n : Nat) : n + 0 = n := by
  rfl

#print axioms nat_add_zero
"""


class TestCoreExample(unittest.TestCase):
    def test_example_loads(self):
        p = Problem.from_json(CORE_EXAMPLE)
        self.assertEqual(p.id, "core-add-zero")
        self.assertEqual(p.import_, "Init")
        self.assertEqual(p.natural, "对任意自然数 n，n + 0 = n")
        self.assertEqual(p.statement, "theorem nat_add_zero (n : Nat) : n + 0 = n")
        self.assertEqual(list(p.allowed_axioms), ["propext"])

    def test_candidate_shape_passes_gate(self):
        p = Problem.from_json(CORE_EXAMPLE)
        self.assertEqual(check_static(CORE_CANDIDATE, p), [])


if __name__ == "__main__":
    unittest.main()
