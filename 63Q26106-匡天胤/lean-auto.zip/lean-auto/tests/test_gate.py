import unittest

from lean_auto.config import Problem
from lean_auto.gate import canonical, check_static, check_statement, compress, strip_comments

STATEMENT = "theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n"
PROBLEM = Problem(
    id="cube",
    natural="对任意整数 n，6 整除 n^3-n",
    statement=STATEMENT,
    allowed_axioms=("propext", "Classical.choice", "Quot.sound"),
)

CLEAN = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""


class TestStripComments(unittest.TestCase):
    def test_line_comment(self):
        self.assertEqual(strip_comments("a -- b\nc"), "a \nc")

    def test_block_comment(self):
        self.assertEqual(strip_comments("a /- x -/ b"), "a  b")

    def test_nested_block_comment(self):
        self.assertEqual(strip_comments("a /- x /- y -/ z -/ b"), "a  b")


class TestCheckStatic(unittest.TestCase):
    def test_clean_code_has_no_issues(self):
        self.assertEqual(check_static(CLEAN, PROBLEM), [])

    def test_multiline_declaration_ok(self):
        code = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) :
    (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""
        self.assertEqual(check_static(code, PROBLEM), [])

    def test_sorry_detected(self):
        issues = check_static(CLEAN.replace("  omega", "  sorry"), PROBLEM)
        self.assertIn("sorry", issues)

    def test_sorry_in_comment_ignored(self):
        code = CLEAN.replace("import Mathlib", "import Mathlib -- sorry 是禁止的")
        code = code.replace("  omega", "  omega /- admit -/")
        self.assertEqual(check_static(code, PROBLEM), [])

    def test_admit_detected(self):
        issues = check_static(CLEAN.replace("  omega", "  admit"), PROBLEM)
        self.assertIn("admit", issues)

    def test_axiom_detected(self):
        code = "axiom magic : True\n" + CLEAN
        self.assertIn("axiom", check_static(code, PROBLEM))

    def test_axioms_word_is_not_axiom_declaration(self):
        # `#print axioms xxx` 里的 axioms 不该被当成 axiom 声明
        self.assertNotIn("axiom", check_static(CLEAN, PROBLEM))

    def test_statement_mismatch(self):
        changed = CLEAN.replace("n ^ 3 - n", "n ^ 3 + n")
        self.assertIn("statement_mismatch", check_static(changed, PROBLEM))

    def test_theorem_renamed_is_mismatch(self):
        changed = CLEAN.replace("n_cube_sub_n_dvd_six", "another_name")
        self.assertIn("statement_mismatch", check_static(changed, PROBLEM))

    def test_no_theorem_is_mismatch(self):
        self.assertIn("statement_mismatch", check_static("import Mathlib\n", PROBLEM))

    def test_statement_in_comment_does_not_count(self):
        code = "import Mathlib\n-- " + STATEMENT + "\n#check 1\n"
        self.assertIn("statement_mismatch", check_static(code, PROBLEM))

    def test_check_statement_and_compress(self):
        self.assertTrue(check_statement(CLEAN, STATEMENT))
        self.assertEqual(compress("a   b\n c"), "a b c")


class TestCanonicalStatement(unittest.TestCase):
    """等价写法不该被误判；只有语义变化才算改题。"""

    def test_int_alias_accepted(self):
        code = CLEAN.replace("(n : ℤ)", "(n : Int)").replace("(6 : ℤ)", "(6 : Int)")
        self.assertEqual(check_static(code, PROBLEM), [])

    def test_fullwidth_parens_accepted(self):
        code = CLEAN.replace("(n : ℤ)", "（n : ℤ）").replace("(6 : ℤ)", "（6 : ℤ）")
        self.assertEqual(check_static(code, PROBLEM), [])

    def test_arrow_forall_aliases(self):
        self.assertEqual(
            canonical("∀ x : ℕ → ℕ, x = x"),
            canonical("forall x : Nat -> Nat, x = x"),
        )

    def test_pipe_reports_symbol_drift(self):
        code = CLEAN.replace("∣ n ^ 3 - n", "| n ^ 3 - n")
        self.assertEqual(check_static(code, PROBLEM), ["symbol_drift"])

    def test_change_of_definition_is_still_mismatch(self):
        code = CLEAN.replace("(6 : ℤ)", "(2 : ℤ)")
        self.assertEqual(check_static(code, PROBLEM), ["statement_mismatch"])


if __name__ == "__main__":
    unittest.main()
