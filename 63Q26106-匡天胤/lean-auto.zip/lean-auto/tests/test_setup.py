import io
import os
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path

from lean_auto import setup as S


def make_fake_lean_zip(path: Path) -> None:
    """造一个结构同官方包的 zip：lean-4.36.0-rc1-linux/bin/lean。"""
    script = "#!/bin/sh\necho 'Lean (version 4.36.0-rc1, x86_64-unknown-linux-gnu)'\n"
    with zipfile.ZipFile(path, "w") as zf:
        info = zipfile.ZipInfo("lean-4.36.0-rc1-linux/bin/lean")
        info.external_attr = (stat.S_IFREG | 0o755) << 16
        zf.writestr(info, script)


class TestUrls(unittest.TestCase):
    def test_direct_and_mirror(self):
        urls = S.lean_urls()
        self.assertEqual(urls[0], "https://github.com/leanprover/lean4/releases/download/v4.36.0-rc1/lean-4.36.0-rc1-linux.zip")
        self.assertIn("ghfast.top", urls[1])

    def test_custom_mirror_only(self):
        urls = S.lean_urls("https://mirror.example/")
        self.assertEqual(len(urls), 1)
        self.assertTrue(urls[0].startswith("https://mirror.example/https://github.com/"))


class TestEnvScript(unittest.TestCase):
    def test_contents(self):
        s = S.env_script(Path("/opt/lean"))
        self.assertIn('export PATH="/opt/lean/lean4/bin:$PATH"', s)
        self.assertIn('export LEAN_CMD="lake env lean"', s)
        self.assertIn('export LEAN_CWD="/opt/lean/mathlib"', s)


class TestPlan(unittest.TestCase):
    def test_plan_fields(self):
        info = S.plan(Path("/tmp/x"), with_mathlib=True)
        for k in ("root", "lean_urls", "lean_zip", "lean_dir", "mathlib_dir", "with_mathlib"):
            self.assertIn(k, info)
        self.assertTrue(info["with_mathlib"])

    def test_dry_run_creates_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "root"
            info = S.setup(root, dry_run=True)
            self.assertFalse(root.exists())
            self.assertEqual(info["root"], str(root))


class TestExtractAndCheck(unittest.TestCase):
    def test_extract_zip(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            zpath = tmp / "fake.zip"
            make_fake_lean_zip(zpath)
            lean_dir = S.extract_zip(zpath, tmp / "root")
            self.assertTrue((lean_dir / "bin" / "lean").exists())
            self.assertIn("4.36.0-rc1", S.check_lean(lean_dir))

    def test_check_lean_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(S.SetupError):
                S.check_lean(Path(tmp))

    def test_extract_rejects_odd_zip(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            zpath = tmp / "two.zip"
            with zipfile.ZipFile(zpath, "w") as zf:
                zf.writestr("a/x", "1")
                zf.writestr("b/y", "2")
            with self.assertRaises(S.SetupError):
                S.extract_zip(zpath, tmp / "root")


class TestFullSetupOffline(unittest.TestCase):
    """把下载源换成本地 file://，跑完整的 setup（不联网）。"""

    def test_setup_end_to_end_no_mathlib(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            archive = tmp / "lean.zip"
            make_fake_lean_zip(archive)
            root = tmp / "root"
            old = (S.lean_urls, S.LEAN_SIZE, S.LEAN_ASSET)
            S.lean_urls = lambda mirror=None: [archive.as_uri()]
            S.LEAN_SIZE = archive.stat().st_size
            S.LEAN_ASSET = archive.name
            try:
                info = S.setup(root, with_mathlib=False)
            finally:
                S.lean_urls, S.LEAN_SIZE, S.LEAN_ASSET = old
            self.assertTrue(info.get("done"))
            self.assertIn("4.36.0-rc1", info["lean_version_actual"])
            env = (root / "env.sh").read_text()
            self.assertIn(str(root), env)
            self.assertTrue((root / "setup.json").exists())


class TestDownloadResume(unittest.TestCase):
    def test_download_file_url(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            src = tmp / "src.bin"
            src.write_bytes(b"x" * 5000)
            dest = tmp / "out.bin"
            S.download([src.as_uri()], dest, expected=5000, retries=1)
            self.assertEqual(dest.read_bytes(), b"x" * 5000)


if __name__ == "__main__":
    unittest.main()
