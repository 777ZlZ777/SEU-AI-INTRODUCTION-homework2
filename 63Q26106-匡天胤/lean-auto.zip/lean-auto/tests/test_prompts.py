import unittest

from lean_auto.config import Problem
from lean_auto.prompts import build_problem_prompt, build_repair_prompt

PROBLEM = Problem(
    id="cube",
    natural="对任意整数 n，6 整除 n^3-n",
    statement="theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n",
    allowed_axioms=("propext", "Classical.choice", "Quot.sound"),
)


class TestPrompts(unittest.TestCase):
    def test_problem_prompt_hard_rules(self):
        p = build_problem_prompt(PROBLEM)
        self.assertIn("import Mathlib", p)
        self.assertIn(PROBLEM.statement, p)
        self.assertIn(PROBLEM.natural, p)
        self.assertIn("#print axioms n_cube_sub_n_dvd_six", p)
        self.assertIn("sorry", p)
        self.assertIn("admit", p)
        self.assertIn("axiom", p)

    def test_repair_prompt_keeps_statement(self):
        p = build_repair_prompt(PROBLEM, "theorem x : True := by trivial", "boom")
        self.assertIn(PROBLEM.statement, p)
        self.assertIn("theorem x : True := by trivial", p)
        self.assertIn("boom", p)
        self.assertIn("#print axioms n_cube_sub_n_dvd_six", p)


CORE = Problem(
    id="core-add-zero",
    natural="对任意自然数 n，n + 0 = n",
    statement="theorem nat_add_zero (n : Nat) : n + 0 = n",
    allowed_axioms=("propext",),
    import_="Init",
)


class TestPromptsImport(unittest.TestCase):
    def test_default_prompt_uses_mathlib(self):
        p = build_problem_prompt(PROBLEM)
        self.assertIn("import Mathlib", p)

    def test_init_prompt_uses_init_and_no_mathlib(self):
        p = build_problem_prompt(CORE)
        self.assertIn("import Init", p)
        self.assertNotIn("import Mathlib", p)
        self.assertIn("#print axioms nat_add_zero", p)

    def test_init_repair_prompt_uses_init_and_no_mathlib(self):
        p = build_repair_prompt(CORE, "theorem nat_add_zero (n : Nat) : n + 0 = n := by rfl", "boom")
        self.assertIn("import Init", p)
        self.assertNotIn("import Mathlib", p)
        self.assertIn("#print axioms nat_add_zero", p)
        self.assertIn("boom", p)


if __name__ == "__main__":
    unittest.main()
