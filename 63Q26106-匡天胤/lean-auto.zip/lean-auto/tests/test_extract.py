import unittest

from lean_auto.extract import ExtractError, extract_lean, theorem_name

GOOD = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""


class TestExtract(unittest.TestCase):
    def test_prefers_lean_fence(self):
        text = "先说思路。\n\n```lean\n%s```\n\n以上是代码。" % GOOD
        self.assertEqual(extract_lean(text), GOOD.strip())

    def test_falls_back_to_plain_fence(self):
        text = "```\n%s```" % GOOD
        self.assertEqual(extract_lean(text), GOOD.strip())

    def test_ignores_other_language_fence_only_when_no_lean(self):
        text = "```python\nprint(1)\n```\n\n```\n%s```" % GOOD
        self.assertEqual(extract_lean(text), GOOD.strip())

    def test_unterminated_lean_fence(self):
        text = "```lean\n%s" % GOOD
        self.assertEqual(extract_lean(text), GOOD.strip())

    def test_fallback_trims_prose(self):
        text = "好的，代码如下：\n%s\n希望对你有帮助。" % GOOD
        self.assertEqual(extract_lean(text), GOOD.strip())

    def test_fallback_all_prose_raises(self):
        with self.assertRaises(ExtractError):
            extract_lean("我没办法证明这道题。")

    def test_no_theorem_in_block_raises(self):
        with self.assertRaises(ExtractError):
            extract_lean("```lean\nimport Mathlib\n#check 1\n```")

    def test_none_raises(self):
        with self.assertRaises(ExtractError):
            extract_lean(None)

    def test_theorem_name(self):
        self.assertEqual(
            theorem_name("theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n"),
            "n_cube_sub_n_dvd_six",
        )
        self.assertEqual(theorem_name("没有定理"), "")


if __name__ == "__main__":
    unittest.main()
