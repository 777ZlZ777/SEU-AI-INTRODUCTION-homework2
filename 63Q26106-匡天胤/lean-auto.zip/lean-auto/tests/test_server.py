import json
import threading
import unittest
import urllib.error
import urllib.request

from lean_auto.runner import RunResult
from lean_auto.server import make_server

STATEMENT = "theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n"
PROBLEM = {
    "id": "cube",
    "natural": "对任意整数 n，6 整除 n^3-n",
    "statement": STATEMENT,
    "allowed_axioms": ["propext", "Classical.choice", "Quot.sound"],
}

GOOD = """import Mathlib

theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n := by
  omega

#print axioms n_cube_sub_n_dvd_six
"""

AXIOMS = "'n_cube_sub_n_dvd_six' depends on axioms: [propext, Classical.choice, Quot.sound]\n"


class FakeRunner:
    def __init__(self):
        self.calls = []

    def __call__(self, code, cfg=None, attempt=1):
        self.calls.append(code)
        ok = "omega" in code
        return RunResult(code=code, exit_code=0 if ok else 1,
                         output=AXIOMS if ok else "x.lean:3:0: error: unknown", duration=0.01)


class FakeLlm:
    def __init__(self, code):
        self.code = code
        self.prompts = []

    def __call__(self, prompt):
        self.prompts.append(prompt)
        return "```lean\n%s\n```" % self.code


class ServerTest(unittest.TestCase):
    def start(self, llm=None, runner=None, concurrency=2):
        self.runner = runner or FakeRunner()
        self.llm = llm or FakeLlm(GOOD)
        self.srv = make_server("127.0.0.1", 0, llm=self.llm, runner=self.runner, concurrency=concurrency)
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.thread.start()
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()

    def post(self, path, payload, raw=None):
        data = raw if raw is not None else json.dumps(payload).encode()
        req = urllib.request.Request(self.base + path, data=data,
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode())

    def get(self, path):
        with urllib.request.urlopen(self.base + path, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode())

    def test_healthz(self):
        self.start()
        status, body = self.get("/healthz")
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])
        self.assertEqual(body["service"], "lean-auto")

    def test_index(self):
        self.start()
        status, body = self.get("/v1")
        self.assertEqual(status, 200)
        self.assertIn("POST /v1/prove", body["endpoints"])

    def test_prove_pass(self):
        self.start()
        status, body = self.post("/v1/prove", {
            "problem": PROBLEM, "model": {"name": "fake"}, "max_attempts": 2,
            "out_dir": "/tmp/lean-auto-server-test",
        })
        self.assertEqual(status, 200, body)
        self.assertTrue(body["ok"])
        self.assertEqual(body["attempts"], 1)
        self.assertEqual(body["axioms"], ["propext", "Classical.choice", "Quot.sound"])
        self.assertIn("omega", body["code"])

    def test_prove_repairs(self):
        bad = GOOD.replace("  omega", "  norm_num")
        self.start(llm=FakeLlm(bad))

        calls = {"n": 0}

        def runner(code, cfg=None, attempt=1):
            calls["n"] += 1
            ok = calls["n"] > 1
            return RunResult(code=code, exit_code=0 if ok else 1,
                             output=AXIOMS if ok else "line 3: error: failed", duration=0.0)

        self.start(llm=FakeLlm(bad), runner=runner)
        status, body = self.post("/v1/prove", {
            "problem": PROBLEM, "model": {"name": "fake"}, "max_attempts": 3,
            "out_dir": "/tmp/lean-auto-server-test",
        })
        self.assertEqual(status, 200, body)
        self.assertTrue(body["ok"])
        self.assertEqual([r["verdict"] for r in body["records"]], ["fail", "pass"])

    def test_prove_without_model_and_env_fails_400(self):
        self.start()
        import os
        saved = os.environ.pop("LLM_MODEL", None)
        try:
            status, body = self.post("/v1/prove", {"problem": PROBLEM})
        finally:
            if saved is not None:
                os.environ["LLM_MODEL"] = saved
        self.assertEqual(status, 400, body)
        self.assertIn("LLM_MODEL", body["error"])

    def test_missing_problem_400(self):
        self.start()
        status, body = self.post("/v1/prove", {"model": {"name": "x"}})
        self.assertEqual(status, 400)

    def test_bad_json_400(self):
        self.start()
        status, body = self.post("/v1/prove", None, raw=b"{not json")
        self.assertEqual(status, 400)

    def test_unknown_route_404(self):
        self.start()
        status, _ = self.post("/v1/nope", {})
        self.assertEqual(status, 404)

    def test_check_ok(self):
        self.start()
        status, body = self.post("/v1/check", {"problem": PROBLEM, "code": GOOD,
                                               "model": {"name": "fake"}})
        self.assertEqual(status, 200, body)
        self.assertTrue(body["ok"])
        self.assertEqual(body["axioms"], ["propext", "Classical.choice", "Quot.sound"])

    def test_check_gate_blocks_without_lean(self):
        self.start()
        bad = GOOD.replace("  omega", "  sorry")
        status, body = self.post("/v1/check", {"problem": PROBLEM, "code": bad,
                                               "model": {"name": "fake"}})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertEqual(body["error_class"], "sorry")
        self.assertEqual(self.runner.calls, [])

    def test_key_not_in_logs(self):
        self.start()
        self.post("/v1/check", {"problem": PROBLEM, "code": GOOD,
                                "model": {"name": "fake", "api_key": "SECRET-XYZ"}})
        # 处理器不写请求日志；这里只断言服务端对象里没有把 key 存起来
        self.assertNotIn("SECRET-XYZ", json.dumps(vars(self.srv), default=str))


if __name__ == "__main__":
    unittest.main()
