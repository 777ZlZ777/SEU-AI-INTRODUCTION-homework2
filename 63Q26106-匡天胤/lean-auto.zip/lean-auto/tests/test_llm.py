import io
import json
import unittest
import urllib.error
from unittest import mock

from lean_auto.config import Config
from lean_auto import llm as llm_mod
from lean_auto.llm import LlmError, complete

CFG = Config(
    base_url="http://127.0.0.1:8080/v1",
    api_key="sk-secret",
    model="fake-model",
    lean_cmd="lean",
    lean_cwd="/tmp",
    lean_timeout=10,
)


class FakeResp:
    def __init__(self, body, status=200):
        self._body = body
        self.status = status

    def read(self):
        return self._body.encode("utf-8")

    def getcode(self):
        return self.status

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class TestComplete(unittest.TestCase):
    def test_returns_content(self):
        payload = {"choices": [{"message": {"content": "hello"}}]}
        with mock.patch.object(
            llm_mod.urllib.request, "urlopen", return_value=FakeResp(json.dumps(payload))
        ) as opener:
            self.assertEqual(complete("hi", CFG), "hello")
            req = opener.call_args[0][0]
            self.assertEqual(req.full_url, "http://127.0.0.1:8080/v1/chat/completions")
            self.assertEqual(req.get_header("Authorization"), "Bearer sk-secret")
            self.assertIn("fake-model", req.data.decode("utf-8"))

    def test_non_200_raises_with_status(self):
        err = urllib.error.HTTPError(
            "http://x", 500, "boom", {}, io.BytesIO(b'{"error":"nope"}')
        )
        with mock.patch.object(llm_mod.urllib.request, "urlopen", side_effect=err):
            with self.assertRaises(LlmError) as ctx:
                complete("hi", CFG)
        self.assertIn("500", str(ctx.exception))

    def test_bad_json_raises(self):
        with mock.patch.object(llm_mod.urllib.request, "urlopen", return_value=FakeResp("{nope")):
            with self.assertRaises(LlmError):
                complete("hi", CFG)

    def test_connection_error_raises(self):
        err = urllib.error.URLError("refused")
        with mock.patch.object(llm_mod.urllib.request, "urlopen", side_effect=err):
            with self.assertRaises(LlmError):
                complete("hi", CFG)

    def test_uses_cfg_llm_timeout_by_default(self):
        cfg = Config(
            base_url="http://x/v1", api_key="", model="m", lean_cmd="lean",
            lean_cwd="/tmp", lean_timeout=1, llm_timeout=7,
        )
        payload = {"choices": [{"message": {"content": "ok"}}]}
        with mock.patch.object(
            llm_mod.urllib.request, "urlopen", return_value=FakeResp(json.dumps(payload))
        ) as opener:
            complete("hi", cfg)
        self.assertEqual(opener.call_args.kwargs["timeout"], 7)

    def test_explicit_timeout_overrides(self):
        payload = {"choices": [{"message": {"content": "ok"}}]}
        with mock.patch.object(
            llm_mod.urllib.request, "urlopen", return_value=FakeResp(json.dumps(payload))
        ) as opener:
            complete("hi", CFG, timeout=3)
        self.assertEqual(opener.call_args.kwargs["timeout"], 3)

    def test_timeout_raises_llm_error(self):
        with mock.patch.object(llm_mod.urllib.request, "urlopen", side_effect=TimeoutError()):
            with self.assertRaises(LlmError) as ctx:
                complete("hi", CFG, timeout=2)
        self.assertIn("超时", str(ctx.exception))

    def test_timeout_wrapped_in_urlerror_raises_llm_error(self):
        err = urllib.error.URLError(TimeoutError("timed out"))
        with mock.patch.object(llm_mod.urllib.request, "urlopen", side_effect=err):
            with self.assertRaises(LlmError) as ctx:
                complete("hi", CFG)
        self.assertIn("超时", str(ctx.exception))

    def test_bad_timeout_value(self):
        with self.assertRaises(LlmError):
            complete("hi", CFG, timeout=0)

    def test_no_api_key_sends_no_auth_header(self):
        cfg = Config(
            base_url="http://x/v1", api_key="", model="m", lean_cmd="lean",
            lean_cwd="/tmp", lean_timeout=1,
        )
        payload = {"choices": [{"message": {"content": "ok"}}]}
        with mock.patch.object(
            llm_mod.urllib.request, "urlopen", return_value=FakeResp(json.dumps(payload))
        ) as opener:
            self.assertEqual(complete("hi", cfg), "ok")
            self.assertIsNone(opener.call_args[0][0].get_header("Authorization"))


if __name__ == "__main__":
    unittest.main()
