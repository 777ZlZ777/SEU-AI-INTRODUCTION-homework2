import unittest

from lean_auto.config import (
    DEFAULT_ALLOWED_AXIOMS,
    DEFAULT_BASE_URL,
    DEFAULT_IMPORT,
    DEFAULT_LEAN_CMD,
    Config,
    ConfigError,
    Problem,
)


class TestConfig(unittest.TestCase):
    def test_model_required(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={})

    def test_defaults(self):
        cfg = Config.from_env(env={"LLM_MODEL": "local"})
        self.assertEqual(cfg.base_url, DEFAULT_BASE_URL)
        self.assertEqual(cfg.lean_cmd, DEFAULT_LEAN_CMD)
        self.assertEqual(cfg.lean_timeout, 180)
        self.assertEqual(cfg.max_attempts, 5)
        self.assertEqual(cfg.llm_timeout, 600)

    def test_llm_timeout_default_600(self):
        cfg = Config.from_env(env={"LLM_MODEL": "local"})
        self.assertEqual(cfg.llm_timeout, 600)

    def test_llm_timeout_from_env(self):
        cfg = Config.from_env(env={"LLM_MODEL": "local", "LLM_TIMEOUT": "5"})
        self.assertEqual(cfg.llm_timeout, 5)

    def test_llm_timeout_not_an_int(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={"LLM_MODEL": "local", "LLM_TIMEOUT": "abc"})

    def test_llm_timeout_zero(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={"LLM_MODEL": "local", "LLM_TIMEOUT": "0"})

    def test_llm_timeout_negative(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={"LLM_MODEL": "local", "LLM_TIMEOUT": "-3"})

    def test_llm_timeout_empty_falls_back(self):
        cfg = Config.from_env(env={"LLM_MODEL": "local", "LLM_TIMEOUT": "  "})
        self.assertEqual(cfg.llm_timeout, 600)

    def test_env_overrides(self):
        cfg = Config.from_env(
            env={
                "LLM_MODEL": "qwen",
                "OPENAI_BASE_URL": "http://127.0.0.1:9000/v1/",
                "OPENAI_API_KEY": "sk-secret",
                "LEAN_CMD": "lean",
                "LEAN_CWD": "/tmp",
                "LEAN_TIMEOUT": "30",
                "LLM_TIMEOUT": "45",
            },
            max_attempts=2,
            out_dir="/tmp/runs",
        )
        self.assertEqual(cfg.base_url, "http://127.0.0.1:9000/v1")
        self.assertEqual(cfg.model, "qwen")
        self.assertEqual(cfg.lean_cmd, "lean")
        self.assertEqual(cfg.lean_cwd, "/tmp")
        self.assertEqual(cfg.lean_timeout, 30)
        self.assertEqual(cfg.llm_timeout, 45)
        self.assertEqual(cfg.max_attempts, 2)
        self.assertEqual(str(cfg.out_dir), "/tmp/runs")

    def test_bad_timeout(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={"LLM_MODEL": "m", "LEAN_TIMEOUT": "abc"})

    def test_bad_max_attempts(self):
        with self.assertRaises(ConfigError):
            Config.from_env(env={"LLM_MODEL": "m"}, max_attempts=0)


class TestProblem(unittest.TestCase):
    def test_default_axioms(self):
        p = Problem.from_dict({"id": "x", "natural": "n", "statement": "theorem t : True"})
        self.assertEqual(p.allowed_axioms, DEFAULT_ALLOWED_AXIOMS)

    def test_missing_field(self):
        with self.assertRaises(ConfigError):
            Problem.from_dict({"id": "x", "natural": "n"})

    def test_from_json_missing_file(self):
        with self.assertRaises(ConfigError):
            Problem.from_json("/definitely/not/here.json")

    def test_from_json_bad_json(self, ):
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "bad.json"
            p.write_text("{nope", encoding="utf-8")
            with self.assertRaises(ConfigError):
                Problem.from_json(p)

    def test_import_defaults_to_mathlib(self):
        p = Problem.from_dict({"id": "x", "natural": "n", "statement": "theorem t : True"})
        self.assertEqual(p.import_, DEFAULT_IMPORT)
        self.assertEqual(p.import_, "Mathlib")

    def test_import_explicit_init(self):
        p = Problem.from_dict(
            {
                "id": "core-add-zero",
                "natural": "n",
                "statement": "theorem nat_add_zero (n : Nat) : n + 0 = n",
                "import": "Init",
            }
        )
        self.assertEqual(p.import_, "Init")

    def test_import_alias_attribute(self):
        p = Problem.from_dict(
            {"id": "x", "natural": "n", "statement": "theorem t : True", "import": "Init"}
        )
        self.assertEqual(getattr(p, "import"), "Init")
        self.assertEqual(getattr(p, "import_"), "Init")

    def test_import_empty_falls_back(self):
        p = Problem.from_dict(
            {"id": "x", "natural": "n", "statement": "theorem t : True", "import": "  "}
        )
        self.assertEqual(p.import_, "Mathlib")

    def test_import_does_not_disturb_other_fields(self):
        p = Problem.from_dict(
            {
                "id": "core-add-zero",
                "natural": "对任意自然数 n，n + 0 = n",
                "statement": "theorem nat_add_zero (n : Nat) : n + 0 = n",
                "import": "Init",
                "allowed_axioms": ["propext"],
            }
        )
        self.assertEqual(p.id, "core-add-zero")
        self.assertEqual(p.allowed_axioms, ("propext",))


if __name__ == "__main__":
    unittest.main()
