import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from lean_auto import cli
from lean_auto.pipeline import PipelineResult


class CliTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.problem = Path(self.tmp.name) / "problem.json"
        self.problem.write_text(
            '{"id":"cube","natural":"n","statement":"theorem t : True"}',
            encoding="utf-8",
        )

    def run_cli(self, argv):
        """CLI 会把错误打到 stderr，测试里静音。"""
        with contextlib.redirect_stderr(io.StringIO()):
            return cli.main(argv)


class TestCli(CliTestCase):
    def test_missing_problem_is_config_error(self):
        self.assertEqual(self.run_cli(["run", "--problem", "/nope.json"]), cli.EXIT_CONFIG)

    def test_missing_model_is_config_error(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertEqual(
                self.run_cli(["run", "--problem", str(self.problem)]), cli.EXIT_CONFIG
            )

    def test_exit_code_matches_result(self):
        for ok, expected in ((True, cli.EXIT_OK), (False, cli.EXIT_FAIL)):
            with mock.patch.dict("os.environ", {"LLM_MODEL": "fake"}, clear=True):
                with mock.patch.object(
                    cli, "run_problem", return_value=PipelineResult(ok=ok)
                ):
                    self.assertEqual(
                        self.run_cli(["run", "--problem", str(self.problem)]), expected
                    )

    def test_llm_error_is_exit_fail(self):
        from lean_auto.llm import LlmError

        with mock.patch.dict("os.environ", {"LLM_MODEL": "fake"}, clear=True):
            with mock.patch.object(cli, "run_problem", side_effect=LlmError("500")):
                self.assertEqual(
                    self.run_cli(["run", "--problem", str(self.problem)]), cli.EXIT_FAIL
                )

    def test_args_parsed(self):
        with mock.patch.dict("os.environ", {"LLM_MODEL": "fake"}, clear=True):
            with mock.patch.object(
                cli, "run_problem", return_value=PipelineResult(ok=True)
            ) as run:
                code = self.run_cli(
                    [
                        "run",
                        "--problem",
                        str(self.problem),
                        "--max-attempts",
                        "3",
                        "--out",
                        "runs",
                    ]
                )
        self.assertEqual(code, cli.EXIT_OK)
        cfg = run.call_args.kwargs["cfg"]
        self.assertEqual(cfg.max_attempts, 3)
        self.assertEqual(str(cfg.out_dir), "runs")
        self.assertEqual(run.call_args.args[0].id, "cube")
