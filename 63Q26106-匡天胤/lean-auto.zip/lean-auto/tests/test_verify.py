import unittest

from lean_auto.config import Problem
from lean_auto.runner import RunResult
from lean_auto.verify import Verdict, axioms_printed, judge, parse_axioms

PROBLEM = Problem(
    id="cube",
    natural="对任意整数 n，6 整除 n^3-n",
    statement="theorem n_cube_sub_n_dvd_six (n : ℤ) : (6 : ℤ) ∣ n ^ 3 - n",
    allowed_axioms=("propext", "Classical.choice", "Quot.sound"),
)

OK_OUTPUT = (
    "import Mathlib took 3s\n"
    "'n_cube_sub_n_dvd_six' depends on axioms: [propext, Classical.choice, Quot.sound]\n"
)
NO_AXIOM_OUTPUT = "'foo' does not depend on any axioms\n"


def res(code, exit_code, output):
    return RunResult(code=code, exit_code=exit_code, output=output, duration=0.1)


class TestParseAxioms(unittest.TestCase):
    def test_parse_list(self):
        self.assertEqual(
            parse_axioms(OK_OUTPUT), ["propext", "Classical.choice", "Quot.sound"]
        )

    def test_parse_empty(self):
        self.assertEqual(parse_axioms(NO_AXIOM_OUTPUT), [])
        self.assertEqual(parse_axioms("depends on axioms: []"), [])

    def test_parse_multiple_prints(self):
        out = (
            "'a' depends on axioms: [propext]\n"
            "'b' depends on axioms: [Quot.sound, propext]\n"
        )
        self.assertEqual(parse_axioms(out), ["propext", "Quot.sound"])

    def test_axioms_printed(self):
        self.assertTrue(axioms_printed(OK_OUTPUT))
        self.assertTrue(axioms_printed(NO_AXIOM_OUTPUT))
        self.assertFalse(axioms_printed("all done"))


class TestJudge(unittest.TestCase):
    def test_pass(self):
        v = judge(res("code", 0, OK_OUTPUT), PROBLEM)
        self.assertTrue(v.ok)
        self.assertEqual(v.error_class, "")
        self.assertEqual(len(v.axioms), 3)

    def test_nonzero_exit_fails(self):
        v = judge(res("code", 1, "error: unknown identifier 'omega'"), PROBLEM)
        self.assertFalse(v.ok)
        self.assertEqual(v.error_class, "lean_exit_nonzero")

    def test_error_in_output_fails(self):
        v = judge(res("code", 0, "foo.lean:3:1: error: tactic failed\n"), PROBLEM)
        self.assertFalse(v.ok)
        self.assertEqual(v.error_class, "lean_error")
        self.assertIn("error:", v.detail)

    def test_sorry_axiom_fails(self):
        out = "'n_cube_sub_n_dvd_six' depends on axioms: [propext, sorryAx]\n"
        v = judge(res("code", 0, out), PROBLEM)
        self.assertFalse(v.ok)
        self.assertEqual(v.error_class, "sorry_axiom")

    def test_unexpected_axiom_fails(self):
        out = "'n_cube_sub_n_dvd_six' depends on axioms: [propext, Quot.sound, myAxiom]\n"
        v = judge(res("code", 0, out), PROBLEM)
        self.assertFalse(v.ok)
        self.assertEqual(v.error_class, "axiom_not_allowed")
        self.assertIn("myAxiom", v.detail)

    def test_no_axiom_output_fails(self):
        v = judge(res("code", 0, "compiled\n"), PROBLEM)
        self.assertFalse(v.ok)
        self.assertEqual(v.error_class, "axioms_not_printed")

    def test_no_dependency_axioms_passes(self):
        v = judge(res("code", 0, NO_AXIOM_OUTPUT), PROBLEM)
        self.assertTrue(v.ok)

    def test_verdict_dataclass_defaults(self):
        v = Verdict(True)
        self.assertEqual(v.axioms, [])
        self.assertEqual(v.detail, "")


if __name__ == "__main__":
    unittest.main()
