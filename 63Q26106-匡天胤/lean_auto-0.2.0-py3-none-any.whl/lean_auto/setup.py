"""首启自举：下载 Lean 工具链与 Mathlib，写环境脚本。

`lean-auto setup` 会把东西放到 --root（默认 ~/.lean-auto）：
  <root>/lean4/       Lean 4.36.0-rc1（解压自官方发布包）
  <root>/mathlib/     Mathlib（git clone + lake exe cache get）
  <root>/env.sh       可直接 source 的环境变量

只用标准库；下载支持断点续传（Range）与镜像前缀。
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

LEAN_VERSION = "v4.36.0-rc1"
LEAN_ASSET = "lean-4.36.0-rc1-linux.zip"
LEAN_SIZE = 942633591
MATHLIB_REPO = "https://github.com/leanprover-community/mathlib4"

DEFAULT_ROOT = Path.home() / ".lean-auto"
MIRRORS = ("", "https://ghfast.top/")  # 空前缀 = 直连
CHUNK = 1 << 20


class SetupError(Exception):
    pass


def lean_urls(mirror: str = None):
    """返回候选下载地址（直连优先，镜像兜底）。"""
    base = "https://github.com/leanprover/lean4/releases/download/%s/%s" % (LEAN_VERSION, LEAN_ASSET)
    if mirror:
        return ["%s%s" % (mirror, base)]
    return ["%s%s" % (m, base) for m in MIRRORS]


def env_script(root: Path) -> str:
    return (
        "# 由 lean-auto setup 生成，直接 source 本文件即可\n"
        'export PATH="%s/lean4/bin:$PATH"\n'
        'export LEAN_CMD="lake env lean"\n'
        'export LEAN_CWD="%s/mathlib"\n'
    ) % (root, root)


def plan(root: Path, with_mathlib: bool = True, mirror: str = None) -> dict:
    return {
        "root": str(root),
        "lean_version": LEAN_VERSION,
        "lean_urls": lean_urls(mirror),
        "lean_zip": str(root / LEAN_ASSET),
        "lean_dir": str(root / "lean4"),
        "mathlib_dir": str(root / "mathlib"),
        "mathlib_repo": MATHLIB_REPO,
        "with_mathlib": with_mathlib,
        "env_script": env_script(root),
    }


def _progress(done: int, total: int, started: float) -> None:
    pct = 100.0 * done / total if total else 0.0
    speed = done / max(time.monotonic() - started, 1e-6) / 1e6
    sys.stdout.write("\r  %5.1f%%  %6.1f / %6.1f MB  (%.1f MB/s)" % (
        pct, done / 1e6, total / 1e6, speed))
    sys.stdout.flush()


def download(urls, dest: Path, expected: int = None, retries: int = 4) -> Path:
    """断点续传下载；任一 URL 成功即返回。"""
    dest.parent.mkdir(parents=True, exist_ok=True)
    last_err = None
    for url in urls:
        for attempt in range(1, retries + 1):
            have = dest.stat().st_size if dest.exists() else 0
            if expected and have >= expected:
                return dest
            headers = {"Range": "bytes=%d-" % have} if have else {}
            req = urllib.request.Request(url, headers=headers)
            try:
                started = time.monotonic()
                with urllib.request.urlopen(req, timeout=60) as resp:
                    mode = "ab" if have and resp.status == 206 else "wb"
                    if mode == "wb":
                        have = 0
                    with open(dest, mode) as fh:
                        while True:
                            chunk = resp.read(CHUNK)
                            if not chunk:
                                break
                            fh.write(chunk)
                            have += len(chunk)
                            if expected:
                                _progress(have, expected, started)
                sys.stdout.write("\n")
                if expected and dest.stat().st_size < expected:
                    raise SetupError("下载不完整：%d / %d" % (dest.stat().st_size, expected))
                return dest
            except Exception as exc:  # noqa: BLE001 - 网络异常统一重试
                last_err = exc
                sys.stdout.write("\n  重试 %d/%d：%s\n" % (attempt, retries, exc))
                time.sleep(2 * attempt)
    raise SetupError("下载失败（%s）：%s" % (urls[0], last_err))


def extract_zip(archive: Path, root: Path) -> Path:
    target = root / "lean4"
    if target.exists():
        return target
    tmp = root / ".lean-tmp"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    with zipfile.ZipFile(archive) as zf:
        zf.extractall(tmp)
        # Python 的 extractall 不还原权限位；Lean 的 bin/ 必须可执行
        for info in zf.infolist():
            mode = (info.external_attr >> 16) & 0o777
            if mode & 0o111:
                target_file = tmp / info.filename
                if target_file.exists():
                    target_file.chmod(mode)
    inner = [p for p in tmp.iterdir() if p.is_dir()]
    if len(inner) != 1:
        raise SetupError("压缩包结构异常：%s" % [p.name for p in inner])
    inner[0].rename(target)
    shutil.rmtree(tmp)
    return target


def check_lean(lean_dir: Path) -> str:
    lean = lean_dir / "bin" / "lean"
    if not lean.exists():
        raise SetupError("没找到 %s" % lean)
    out = subprocess.run([str(lean), "--version"], capture_output=True, text=True)
    if out.returncode != 0:
        raise SetupError("lean --version 失败：%s" % out.stderr[:300])
    return out.stdout.strip()


def clone_mathlib(root: Path, repo: str = MATHLIB_REPO) -> Path:
    dest = root / "mathlib"
    if dest.exists():
        return dest
    if shutil.which("git") is None:
        raise SetupError("需要 git 才能拉 Mathlib（未找到 git）")
    print("  git clone --depth 1 %s" % repo)
    out = subprocess.run(["git", "clone", "--depth", "1", repo, str(dest)],
                         capture_output=True, text=True)
    if out.returncode != 0:
        raise SetupError("git clone 失败：%s" % (out.stderr or out.stdout)[:500])
    return dest


def fetch_cache(mathlib_dir: Path, lean_dir: Path) -> None:
    env = dict(os.environ)
    env["PATH"] = "%s/bin:%s" % (lean_dir, env.get("PATH", ""))
    print("  lake exe cache get（约 3–4GB）")
    out = subprocess.run(["lake", "exe", "cache", "get"], cwd=str(mathlib_dir),
                         env=env, capture_output=True, text=True)
    if out.returncode != 0:
        raise SetupError("cache get 失败：%s" % (out.stderr or out.stdout)[-800:])


def setup(root: Path = DEFAULT_ROOT, with_mathlib: bool = True,
          mirror: str = None, dry_run: bool = False) -> dict:
    root = Path(root).expanduser().resolve()
    info = plan(root, with_mathlib, mirror)
    if dry_run:
        return info
    root.mkdir(parents=True, exist_ok=True)
    print("[1/4] 下载 Lean %s（%s）" % (LEAN_VERSION, LEAN_ASSET))
    archive = download(info["lean_urls"], Path(info["lean_zip"]), LEAN_SIZE)
    print("[2/4] 解压到 %s" % info["lean_dir"])
    lean_dir = extract_zip(archive, root)
    version = check_lean(lean_dir)
    print("      %s" % version)
    if with_mathlib:
        print("[3/4] 拉 Mathlib 源码与依赖")
        mathlib = clone_mathlib(root)
        print("[4/4] 下载预编译 olean")
        fetch_cache(mathlib, lean_dir)
    env_file = root / "env.sh"
    env_file.write_text(env_script(root), encoding="utf-8")
    (root / "setup.json").write_text(json.dumps({
        "lean_version": LEAN_VERSION, "root": str(root), "mathlib": with_mathlib,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**info, "done": True, "lean_version_actual": version,
            "env_file": str(env_file)}


def main(args) -> int:
    root = Path(args.root).expanduser() if args.root else DEFAULT_ROOT
    mirror = args.mirror if args.mirror is not None else None
    try:
        info = setup(root, with_mathlib=not args.no_mathlib, mirror=mirror, dry_run=args.dry_run)
    except SetupError as exc:
        print("[setup] 失败：%s" % exc, file=sys.stderr)
        return 1
    if args.dry_run:
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0
    print("\n完成。source %s 之后即可：\n  lean-auto run --problem <problem.json>" % info["env_file"])
    return 0
